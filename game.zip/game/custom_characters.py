import renpy.character
import renpy.config
import renpy.exports as renpy

Character = renpy.character.Character

class NoSkipCharacter(Character):
    def __call__(self, what, **kwargs):
        _old_skipping = renpy.config.skipping
        _old_say_allow_dismiss = renpy.config.say_allow_dismiss

        try:
            renpy.config.skipping = False
            renpy.config.say_allow_dismiss = False

            super(NoSkipCharacter, self).__call__(what, **kwargs)

        finally:
            renpy.config.skipping = _old_skipping
            renpy.config.say_allow_dismiss = _old_say_allow_dismiss