﻿################################################################################
## 초기화
################################################################################

init offset = -1


################################################################################
## 스타일
################################################################################

style default:
    properties gui.text_properties()
    language gui.language

style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

style hyperlink_text:
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True

style gui_text:
    properties gui.text_properties("interface")


style button:
    properties gui.button_properties("button")

style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5


style label_text is gui_text:
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    properties gui.text_properties("prompt")


style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.png"

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"


style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)



################################################################################
## 게임내 스크린
################################################################################


## Say 스크린 #####################################################################
##
## Say 스크린은 플레이어에게 대사를 출력할 때 씁니다. 화자 who와 대사 what, 두
## 개의 매개변수를 받습니다. (화자 이름이 없으면 who는 None일 수 있음)
##
## 이 스크린은 id "what"을 가진 텍스트 디스플레이어블을 생성해야 합니다. (이 디
## 스플레이어블은 렌파이의 대사 출력에 필요합니다.) id "who" 와 id "window" 디스
## 플레이블이 존재할 경우 관련 스타일 속성이 적용됩니다.
##
## https://www.renpy.org/doc/html/screen_special.html#say



screen say(who, what):

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "namebox"
                text who id "who":
                    xpos 20
                    ypos -15

        text what id "what":
            ypos 25

    ## 사이드 이미지가 있는 경우 글자 위에 표시합니다. 휴대폰 환경에서는 보이지
    ## 않습니다.
    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0
    

## Character 객체를 통해 스타일을 지정할 수 있도록 namebox를 사용할 수 있게 만듭
## 니다.
init python:
    config.character_id_prefixes.append('namebox')

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    background Image("gui/textbox.png", xalign=0.5, yalign=1.0)

style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding

style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5

style say_dialogue:
    properties gui.text_properties("dialogue")

    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos

    adjust_spacing False

## Input 스크린 ###################################################################
##
## 플레이어 입력을 받는 renpy.input을 출력할 때 쓰이는 스크린입니다. prompt 매개
## 변수를 통해 입력 지문을 표시할 수 있습니다.
##
## 이 스크린은 id "input"을 가진 input 디스플레이어블을 생성해야 합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#input


screen input(prompt):
    style_prefix "input"

    window:

        vbox:
            xanchor gui.dialogue_text_xalign
            xpos gui.dialogue_xpos
            xsize gui.dialogue_width
            ypos gui.dialogue_ypos

            text prompt style "input_prompt"
            input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width

## name_input ####################################################################
init python:
    style.centered_input = Style(style.input)
    style.centered_input.textalign = 0.5
    style.centered_input.xsize = 240   # 가로 고정
    style.centered_input.size = 30    # 폰트 사이즈(원하는 대로)
    style.centered_input.font = "DungGeunMo.ttf"


screen input_name():
    frame:
        text "당신의 이름은?" size 30 font "DungGeunMo.ttf":
            xalign 0.5 # 당신의 이름은? 폰트 위치
            yalign 0.1
        xysize (500,250)
        xalign 0.5 # 박스 위치
        yalign 0.5
        padding (30, 30)
        vbox:
            spacing 30
            xalign 0.5 # 입력텍스트 위치
            yalign 0.8
            
            input id "name_input" value VariableInputValue("temp_player_name") length 12 style "centered_input" xmaximum 600
            textbutton "확인":
                xalign 0.5
                action [SetVariable("player_name", temp_player_name), Return()]
                sensitive temp_player_name.strip() != ""

## 진행도 스크린 ###################################################################
image chapter_locked = "images/chapter/locked.png"
image chapter_clear = "images/chapter/clear.png"
image chapter_current = "images/chapter/black.png"
image check = "images/chapter/check.png"
image arrow = "images/chapter/arrow.png"

init python:
    # 챕터 박스 크기 및 간격 정의 (render 함수에서 사용하기 위해 전역으로 정의)
    _chapter_box_width = 250
    _chapter_box_height = 300
    _chapter_xspacing = 80
    _chapter_yspacing = 30
    _display_rows = 3 # 한 열당 최대 행 수
    _chapters_total = 12 # 총 챕터 수 (render 함수에서 사용)

    # 챕터 중심 좌표를 미리 계산하여 저장할 딕셔너리
    _chapter_centers_map = {}

    # 각 챕터의 중심 좌표를 계산하여 _chapter_centers_map에 저장
    for i in range(_chapters_total):
        if i == 11: # 챕터 12 (인덱스 11) 특수 위치
            col = 4
            row = 1
        else: # 나머지 챕터 일반 위치
            col = i // _display_rows
            row = i % _display_rows
        
        x_center = (_chapter_box_width + _chapter_xspacing) * col + _chapter_box_width / 2
        y_center = (_chapter_box_height + _chapter_yspacing) * row + _chapter_box_height / 2
        _chapter_centers_map[i] = (x_center, y_center)

    # 연결 관계 정의 (챕터 인덱스 기준)
    # (시작 챕터 인덱스, 끝 챕터 인덱스, 선 색상)
    _chapter_connections = [
        (0, 1, "#F3E2A9"), # 학과 개강총회 -> 강의 OT (노란색)
        (0, 3, "#F3E2A9"), # 학과 개강총회 -> 이사 (노란색)
        (1, 4, "#A9D9F3"), # 강의 OT -> 벚꽃놀이 (파란색)
        (2, 5, "#A9F3A9"), # 첫눈에 반하다 -> 밥 약속 (초록색)
        (3, 6, "#F3E2A9"), # 이사 -> 커피 (노란색)
        (4, 7, "#A9D9F3"), # 벚꽃놀이 -> 비 오는 날 도서관 (파란색)
        (5, 8, "#A9F3A9"), # 밥 약속 -> 동아리 회식 (초록색)
        (6, 9, "#F3E2A9"), # 커피 -> 동아리 MT (노란색)
        (7, 10, "#A9D9F3"), # 비 오는 날 도서관 -> 학과 MT (파란색)
        (8, 9, "#A9F3A9"), # 동아리 회식 -> 동아리 MT (초록색)
        (9, 11, "#FFFFFF"), # 동아리 MT -> 여름방학 (흰색)
        (10, 11, "#FFFFFF") # 학과 MT -> 여름방학 (흰색)
    ]

    # 캔버스 렌더링 함수 정의
    def render_chapter_lines(width, height, st, at):
        rv = renpy.Render(width, height) # 렌더 객체 생성
        line_width = 5 # 선 두께 (조절 가능)

        for start_idx, end_idx, color in _chapter_connections:
            if start_idx in _chapter_centers_map and end_idx in _chapter_centers_map:
                start_pos = _chapter_centers_map[start_idx]
                end_pos = _chapter_centers_map[end_idx]

                line_color = renpy.color.Color(color)
                # 캔버스에 선 그리기
                rv.canvas.line(line_color, start_pos, end_pos, line_width)
        
        return rv

screen chapter_progress():

    default chapters = 12 # 챕터 수를 12개로 가정합니다.
    # 챕터별 이름을 정의하는 리스트입니다.
    # 두 번째 사진의 챕터 이름을 기반으로 작성되었습니다.
    # 챕터 수가 변경되면 이 리스트의 길이도 맞춰주세요.
    default chapter_names = [
        "학과 개강총회", # chapter_idx 0 (1번 위치)
        "강의 OT",      # chapter_idx 1 (2번 위치)
        "첫눈에 반하다",  # chapter_idx 2 (3번 위치)
        "이사",         # chapter_idx 3 (4번 위치)
        "벚꽃놀이",      # chapter_idx 4 (5번 위치)
        "밥 약속",      # chapter_idx 5 (6번 위치)
        "커피",         # chapter_idx 6 (7번 위치)
        "비 오는 날 도서관", # chapter_idx 7 (8번 위치)
        "동아리 회식",    # chapter_idx 8 (9번 위치)
        "동아리 MT",    # chapter_idx 9 (10번 위치)
        "학과 MT",      # chapter_idx 10 (11번 위치)
        "여름방학"      # chapter_idx 11 (12번 위치 - 특수 위치)
    ]
    default chapter_colors_map = { # 색상 이름을 직접 매핑하여 사용
        0: "yellow", 1: "blue", 2: "green",
        3: "yellow", 4: "blue", 5: "green",
        6: "yellow", 7: "blue", 8: "green",
        9: "yellow", 10: "blue", 11: "white"
    }

    # 클리어된 챕터 박스 이미지 경로 정의 (글자가 박힌 이미지)
    # 예: images/chapter/chapter_box_cleared_0.png
    # 실제 파일명과 일치하도록 수정해야 합니다.
    default chapter_box_cleared_paths = [
        "images/chapter/chapter_box/chapter_box_soodal_0.png",  # 학과 개강총회
        "images/chapter/chapter_box/chapter_box_heron_0.png",  # 강의 OT
        "images/chapter/chapter_box/chapter_box_turtle_0.png",  # 첫눈에 반하다
        "images/chapter/chapter_box/chapter_box_soodal_1.png",  # 이사
        "images/chapter/chapter_box/chapter_box_heron_1.png",  # 벚꽃놀이
        "images/chapter/chapter_box/chapter_box_turtle_1.png",  # 밥 약속
        "images/chapter/chapter_box/chapter_box_soodal_2.png",  # 커피
        "images/chapter/chapter_box/chapter_box_heron_2.png",  # 비 오는 날 도서관
        "images/chapter/chapter_box/chapter_box_turtle_2.png",  # 동아리 회식
        "images/chapter/chapter_box/chapter_box_soodal_3.png",  # 동아리 MT
        "images/chapter/chapter_box/chapter_box_heron_3.png", # 학과 MT
        "images/chapter/chapter_box/chapter_box_vacation.png"  # 여름방학
    ]

    # 미클리어된 챕터 박스 이미지 경로 정의 (각 색깔에 맞는 locked 이미지)
    # 예: images/chapter/chapter_box_yellow_locked.png
    # 실제 파일명과 일치하도록 수정해야 합니다.
    default chapter_box_locked_paths = [
        "images/chapter/chapter_box/chapter_box_soodal_locked.png", # chapter_idx 0
        "images/chapter/chapter_box/chapter_box_heron_locked.png",   # chapter_idx 1
        "images/chapter/chapter_box/chapter_box_turtle_locked.png",  # chapter_idx 2
        "images/chapter/chapter_box/chapter_box_soodal_locked.png", # chapter_idx 3
        "images/chapter/chapter_box/chapter_box_heron_locked.png",   # chapter_idx 4
        "images/chapter/chapter_box/chapter_box_turtle_locked.png",  # chapter_idx 5
        "images/chapter/chapter_box/chapter_box_soodal_locked.png", # chapter_idx 6
        "images/chapter/chapter_box/chapter_box_heron_locked.png",   # chapter_idx 7
        "images/chapter/chapter_box/chapter_box_turtle_locked.png",  # chapter_idx 8
        "images/chapter/chapter_box/chapter_box_soodal_locked.png", # chapter_idx 9
        "images/chapter/chapter_box/chapter_box_heron_locked.png",   # chapter_idx 10
        "images/chapter/chapter_box/chapter_box_white_locked.png"   # chapter_idx 11
    ]

    tag menu
    modal True

    default scroll_x = 0.0  # 수평 스크롤 위치 변수

    # 화면에 표시될 그리드의 행/열 수 정의 (이미지 기반)
    default display_rows = 3 # 한 열당 최대 행 수 (대부분의 열은 3줄)
    default max_display_cols = 5 # 챕터 12를 포함하기 위한 최대 열 수 (5열)

    # 챕터 박스의 크기 및 간격 정의
    default chapter_box_width = 250
    default chapter_box_height = 250 
    default chapter_xspacing = 70    
    default chapter_yspacing = 0     

    # fixed_xsize와 fixed_ysize를 스크린의 default 변수로 미리 계산합니다.
    default fixed_xsize = (chapter_box_width * max_display_cols + chapter_xspacing * (max_display_cols - 1)) if max_display_cols > 0 else 0
    default fixed_ysize = (chapter_box_height * display_rows + chapter_yspacing * (display_rows - 1)) if display_rows > 0 else 0

    add "#000"  # 전체 배경을 검은색으로

    frame:
        xalign 0.5
        yalign 0.5
        xysize (1280, 720) 
        background None 
        
        has viewport:
            xfill True
            ysize 650 
            scrollbars "horizontal"
            mousewheel False
            draggable True
            xpos scroll_x

            # 뷰포트의 유일한 자식으로 하나의 fixed 컨테이너를 추가합니다.
            # 이 fixed 컨테이너가 챕터 박스들과 연결선 배경 이미지를 모두 포함합니다.
            fixed:
                xsize fixed_xsize # 뷰포트 내부 스크롤 가능한 콘텐츠의 전체 너비
                ysize fixed_ysize # 뷰포트 내부 스크롤 가능한 콘텐츠의 전체 높이

                # 챕터 연결선이 그려진 배경 이미지를 추가합니다.
                # Image()를 사용하여 xfill과 yfill 속성을 명시적으로 전달합니다.
                add Image("images/chapter/chapter_map_lines.png", xfill=True, yfill=True)
                # 참고: 이 이미지 파일은 직접 만들어야 합니다.

                # 챕터 박스들을 직접 배치하는 fixed (이 fixed는 연결선 배경 이미지 위에 그려집니다)
                fixed:
                    xfill True # 부모 fixed의 크기를 채웁니다.
                    yfill True 

                    # 각 챕터에 대해 반복하며 위치를 계산합니다.
                    for chapter_idx in range(chapters):
                        # 챕터 12 (인덱스 11)에 대한 특수 처리
                        if chapter_idx == 11:
                            # 챕터 12는 5번째 열 (인덱스 4), 2번째 행 (인덱스 1)에 위치
                            $ current_col_idx = 4
                            $ current_row_idx = 1
                        else:
                            # 나머지 챕터는 일반적인 열 우선 순서로 배치
                            $ current_col_idx = chapter_idx // display_rows
                            $ current_row_idx = chapter_idx % display_rows

                        # 실제 챕터 수 범위 내에 있는 경우에만 챕터 박스를 표시
                        if chapter_idx < chapters: 
                            # 챕터 클리어 여부 확인 (persistent.current_chapter는 1부터 시작한다고 가정)
                            # chapter_idx는 0부터 시작하므로 persistent.current_chapter와 비교 시 +1 보정
                            $ cleared = 1 if persistent.current_chapter > chapter_idx else 0
                            # 현재 챕터인지 확인
                            $ current = persistent.current_chapter == chapter_idx + 1
                            
                            fixed:
                                xysize (chapter_box_width, chapter_box_height)
                                # 계산된 xpos와 ypos를 사용하여 해당 위치에 배치
                                xpos (chapter_box_width + chapter_xspacing) * current_col_idx 
                                ypos (chapter_box_height + chapter_yspacing) * current_row_idx 
                                
                                # 챕터 박스 이미지 선택 (수정된 부분)
                                # 클리어되면 글자까지 박힌 이미지, 미클리어시 각 색깔에 맞는 locked 이미지 출력
                                $ box_image_path = ""
                                if cleared:
                                    # 클리어된 챕터는 chapter_box_cleared_paths에서 해당 이미지 사용
                                    $ box_image_path = chapter_box_cleared_paths[chapter_idx] if chapter_idx < len(chapter_box_cleared_paths) else "images/chapter/chapter_box_default_cleared.png" # 안전을 위한 기본값
                                else:
                                    # 미클리어된 챕터는 chapter_box_locked_paths에서 해당 locked 이미지 사용
                                    $ box_image_path = chapter_box_locked_paths[chapter_idx] if chapter_idx < len(chapter_box_locked_paths) else "images/chapter/chapter_box_default_locked.png" # 안전을 위한 기본값
                                
                                add box_image_path # 이미지 파일 추가

                                # 텍스트 출력은 제거됩니다.
                                # text title:
                                #     xalign 0.5
                                #     yalign 0.11
                                #     size 28
                                                                # "현재" 텍스트 표시
                                # persistent.current_chapter는 1부터 시작하므로 chapter_idx + 1과 비교
                                if current: # 현재 챕터인 경우
                                    text "{font=fonts/DungGeunmo.ttf}현재{/font}":
                                        xalign 0.35
                                        yalign 0.3 # 박스 아래쪽에 위치
                                        yoffset 40 # 박스 아래로 30px 내림
                                        size 24
                                        color "#FFFFFF" # 흰색 텍스트

                                # "next" 텍스트 표시
                                # 다음에 진행할 챕터는 persistent.current_chapter (1-indexed)에 해당
                                # 즉, chapter_idx (0-indexed)가 persistent.current_chapter와 같고, 아직 클리어되지 않은 경우
                                if chapter_idx == persistent.current_chapter and not cleared:
                                    text "{font=fonts/DungGeunmo.ttf}Next{/font}":
                                        xalign 0.35
                                        yalign 0.3 # 박스 아래쪽에 위치
                                        yoffset 40 # 박스 아래로 30px 내림
                                        size 24
                                        color "#FFFFFF" # 흰색 텍스트

                                #if cleared and not current:
                                #    add "images/chapter/check.png" xpos 5 ypos -60

                                #if current:
                                #    add "images/chapter/arrow.png" xpos 100 ypos -100 xanchor 0.5



    # 왼쪽/오른쪽 이동 버튼

    textbutton "계속":
        xalign 0.5
        yalign 0.97
        action Return()

## Choice 스크린 ##################################################################
##
## menu 명령어로 생성된 게임내 선택지를 출력하는 스크린입니다. 한 개의 매개변수
## items를 받고, 이는 선택지 내용(caption)과 선택지 결과(action)이 있는 오브젝트
## 가 들어있는 리스트입니다.
##
## https://www.renpy.org/doc/html/screen_special.html#choice

screen choice(items):
    style_prefix "choice"

    vbox:
        for i in items:
            textbutton i.caption action i.action


style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    ypos 270
    yanchor 0.5

    spacing gui.choice_spacing

style choice_button is default:
    properties gui.button_properties("choice_button")

style choice_button_text is default:
    properties gui.text_properties("choice_button")


## Quick Menu 스크린 ##############################################################
##
## 퀵메뉴는 게임 외 메뉴 접근성을 높여주기 위해 게임 내에 표시됩니다.

screen quick_menu():

    ## 다른 화면 위에 표시되는지 확인합니다.
    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("되감기") action Rollback()
            textbutton _("대사록") action ShowMenu('history')
            textbutton _("넘기기") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("자동진행") action Preference("auto-forward", "toggle")
            textbutton _("저장") action ShowMenu('save')
            textbutton _("Q.저장") action QuickSave()
            textbutton _("Q.불러오기") action QuickLoad()
            textbutton _("설정") action ShowMenu('preferences')

style quick_button_text is button_text:
    font "fonts/DungGeunMo.ttf"
    insensitive_color "#888888"

transform slide_fade_y:
    on show:
        yoffset -100
        alpha 0.0
        easein 0.3 yoffset 0 alpha 1.0
    on hide:
        easeout 0.3 yoffset -100 alpha 0.0

screen top_quick_menu():

    default is_hovering = False

    mousearea:
        area (0, 0, 1280, 50)
        hovered SetScreenVariable("is_hovering", True)
        unhovered SetScreenVariable("is_hovering", False)

    showif not is_hovering:
        add "gui/quickmenu_arrow.png" at slide_fade_y:
            xalign 0.5
            ypos -8

    showif is_hovering:
        add "gui/quickmenu.png" at slide_fade_y:
            xalign 0.5
            yalign 0.0

        fixed at slide_fade_y:
            yalign 0.0
            yoffset 5  # 배경 이미지 안에서 아래쪽으로 약간 내리기
            xoffset 400
            hbox:
                style_prefix "quick"
                spacing -5
                textbutton "자동진행" action Preference("auto-forward", "toggle")
                textbutton "저장" action ShowMenu("save")
                textbutton "빠른저장" action QuickSave()
                textbutton "로드" action ShowMenu("load")
                textbutton "빠른로드" action QuickLoad()
                textbutton "대사록" action ShowMenu("history")


# 트랜스폼: 인자 없이 따로 정의
transform quick_menu_show:
    yoffset -60
    easein 0.3 yoffset 0

transform quick_menu_hide:
    easeout 0.3 yoffset -60

    
## 플레이어가 UI(스크린)을 일부러 숨기지 않는 한 퀵메뉴가 게임 내에 오버레이로
## 출력되게 합니다.
init python:
    #config.overlay_screens.append("quick_menu")
    config.overlay_screens.append("top_quick_menu")
#default quick_menu = True


style quick_button is default
style quick_button_text is button_text

style quick_button:
    properties gui.button_properties("quick_button")

style quick_button_text:
    properties gui.text_properties("quick_button")
################################################################################
## Main과 Game Menu 스크린
################################################################################

## Navigation 스크린 ##############################################################
##
## 이 스크린은 메인메뉴와 게임외 메뉴에 포함되어 다른 메뉴로 이동하거나 게임을
## 시작/종료할 수 있게 합니다.

screen navigation():

    vbox:
        style_prefix "navigation"

        xpos gui.navigation_xpos
        yalign 0.5

        spacing gui.navigation_spacing

        if main_menu:

            textbutton _("시작하기") action Start()

        else:

            textbutton _("대사록") action ShowMenu("history")

            textbutton _("저장하기") action ShowMenu("save")

        textbutton _("불러오기") action ShowMenu("load")

        textbutton _("환경설정") action ShowMenu("preferences")

        if _in_replay:

            textbutton _("리플레이 끝내기") action EndReplay(confirm=True)

        elif not main_menu:

            textbutton _("메인 메뉴") action MainMenu()

        textbutton _("버전정보") action ShowMenu("about")

        if renpy.variant("pc") or (renpy.variant("web") and not renpy.variant("mobile")):

            ## 도움말 메뉴는 모바일 디바이스와 맞지 않아 불필요합니다.
            textbutton _("조작방법") action ShowMenu("help")

        if renpy.variant("pc"):

            ## iOS에서는 종료 버튼이 금지되어 있으며 Android 및 웹에서는 불필요
            ## 합니다.
            textbutton _("종료하기") action Quit(confirm=not main_menu)


style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    size_group "navigation"
    properties gui.button_properties("navigation_button")

style navigation_button_text:
    properties gui.text_properties("navigation_button")


## Main Menu 스크린 ###############################################################
##
## 렌파이가 시작할 때 메인메뉴를 출력합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#main-menu

screen main_menu():

    ## 이렇게 하면 다른 메뉴 화면이 모두 교체됩니다.
    tag menu

    add gui.main_menu_background
    add "gui/logo.png" xpos 100
    ## 이 빈 프레임은 기본 메뉴를 어둡게 만듭니다.
    frame:
        style "main_menu_frame"

    ## use 명령어로 스크린 내에 다른 스크린을 불러옵니다. 메인 메뉴 스크린의 내
    ## 용물은 navigation 스크린에 있습니다.
    
    use navigation
    
    # 버전 출력
    if gui.show_name:

        vbox:
            style "main_menu_vbox"

            #text "[config.name!t]":
                #style "main_menu_title"

            #text "[config.version]":
                #style "main_menu_version"


style main_menu_frame is empty
style main_menu_vbox is vbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text

style main_menu_frame:
    xsize 280
    yfill True

    background "gui/overlay/main_menu2.png"

style main_menu_vbox:
    xalign 1.0
    xoffset -20
    xmaximum 800
    yalign 1.0
    yoffset -20

style main_menu_text:
    properties gui.text_properties("main_menu", accent=True)

style main_menu_title:
    properties gui.text_properties("title")

style main_menu_version:
    properties gui.text_properties("version")


## Game Menu 스크린 ###############################################################
##
## 게임 메뉴의 기본 틀입니다. 매개변수 title로 스크린 제목을 정하고, 배경, 제목,
## 그리고 navigation 스크린을 출력합니다.
##
## scroll 매개변수는, None, "viewport" 혹은 "vpgrid" 중 하나여야 합니다.
## transclude 명령어를 통해 다른 스크린을 이 스크린 내부에 불러옵니다.

screen game_menu(title, scroll=None, yinitial=0.0, spacing=0):

    style_prefix "game_menu"

    if main_menu:
        add gui.main_menu_background
    else:
        add gui.game_menu_background

    frame:
        style "game_menu_outer_frame"

        hbox:

            ## 탐색 섹션을 위한 공간 예약.
            frame:
                style "game_menu_navigation_frame"

            frame:
                style "game_menu_content_frame"

                if scroll == "viewport":

                    viewport:
                        yinitial yinitial
                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        pagekeys True

                        side_yfill True

                        vbox:
                            spacing spacing

                            transclude

                elif scroll == "vpgrid":

                    vpgrid:
                        cols 1
                        yinitial yinitial

                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        pagekeys True

                        side_yfill True

                        spacing spacing

                        transclude

                else:

                    transclude

    use navigation

    textbutton _("돌아가기"):
        style "return_button"

        action Return()

    label title

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")


style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_outer_frame:
    bottom_padding 30
    top_padding 120

    background "gui/overlay/game_menu.png"

style game_menu_navigation_frame:
    xsize 280
    yfill True

style game_menu_content_frame:
    left_margin 40
    right_margin 20
    top_margin 10

style game_menu_viewport:
    xsize 920

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 10

style game_menu_label:
    xpos 50
    ysize 120

style game_menu_label_text:
    size gui.title_text_size
    color gui.accent_color
    yalign 0.5

style return_button:
    xpos gui.navigation_xpos
    yalign 1.0
    yoffset -30


## About 스크린 ###################################################################
##
## 이 스크린은 게임과 렌파이 엔진 크레딧과 저작권 정보를 표시합니다.
##
## 특별할 것이 없으므로 스크린을 새로 커스터마이징하여 만드는 예제이기도 합니다.

screen about():

    tag menu

    ## 이 use 명령어로 game_menu 스크린을 이 스크린 내에 불러옵니다. use 명령어
    ## 하위블럭(vbox 내용)은 game_menu 스크린 내 transclude 명령어가 있는 곳에
    ## 다시 불려집니다.
    use game_menu(_("버전정보"), scroll="viewport"):

        style_prefix "about"

        vbox:

            label "[config.name!t]"
            text _("버전 [config.version!t]\n")

            ## gui.about 의 내용은 보통 options.rpy에 있습니다.
            if gui.about:
                text "[gui.about!t]\n"

            text _("{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only] 으로 만들어진 게임.\n\n[renpy.license!t]")


style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text

style about_label_text:
    size gui.label_text_size


## Load 그리고 Save 스크린 ###########################################################
##
## 이 스크린은 세이브/로드에 쓰입니다. 거의 동일하기 때문에, file_slots 스크린을
## 불러와서 씁니다.
##
## https://www.renpy.org/doc/html/screen_special.html#save https://
## www.renpy.org/doc/html/screen_special.html#load

screen save():

    tag menu

    use file_slots(_("저장하기"))


screen load():

    tag menu

    use file_slots(_("불러오기"))


screen file_slots(title):

    default page_name_value = FilePageNameInputValue(pattern=_("{} 페이지"), auto=_("자동 세이브"), quick=_("퀵세이브"))

    use game_menu(title):

        fixed:

            ## input이 세이브/로드 버튼보다 먼저 엔터에 반응하도록 합니다.
            order_reverse True

            ## 페이지 제목을 플레이어가 수정할 수 있음.
            button:
                style "page_label"

                key_events True
                xalign 0.5
                action page_name_value.Toggle()

                input:
                    style "page_label_text"
                    value page_name_value

            ## 파일 슬롯 그리드.
            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"

                xalign 0.5
                yalign 0.5

                spacing gui.slot_spacing

                for i in range(gui.file_slot_cols * gui.file_slot_rows):

                    $ slot = i + 1

                    button:
                        action FileAction(slot)

                        has vbox

                        add FileScreenshot(slot) xalign 0.5

                        text FileTime(slot, format=_("{#file_time}%A, %B %d %Y, %H:%M"), empty=_("빈 슬롯")):
                            style "slot_time_text"

                        text FileSaveName(slot):
                            style "slot_name_text"

                        key "save_delete" action FileDelete(slot)

            ## 페이지 이동 버튼.
            vbox:
                style_prefix "page"

                xalign 0.5
                yalign 1.0

                hbox:
                    xalign 0.5

                    spacing gui.page_spacing

                    textbutton _("<") action FilePagePrevious()
                    key "save_page_prev" action FilePagePrevious()

                    if config.has_autosave:
                        textbutton _("{#auto_page}자동") action FilePage("auto")

                    if config.has_quicksave:
                        textbutton _("{#quick_page}퀵") action FilePage("quick")

                    ## 범위(1, 10)는 1부터 9까지 숫자를 제공합니다.
                    for page in range(1, 10):
                        textbutton "[page]" action FilePage(page)

                    textbutton _(">") action FilePageNext()
                    key "save_page_next" action FilePageNext()

                if config.has_sync:
                    if CurrentScreenName() == "save":
                        textbutton _("동기화 업로드"):
                            action UploadSync()
                            xalign 0.5
                    else:
                        textbutton _("동기화 다운로드"):
                            action DownloadSync()
                            xalign 0.5


style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text

style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 50
    ypadding 3

style page_label_text:
    textalign 0.5
    layout "subtitle"
    hover_color gui.hover_color

style page_button:
    properties gui.button_properties("page_button")

style page_button_text:
    properties gui.text_properties("page_button")

style slot_button:
    properties gui.button_properties("slot_button")

style slot_button_text:
    properties gui.text_properties("slot_button")


## Preferences 스크린 #############################################################
##
## Preferences 스크린에서는 각종 환경설정을 플레이어가 지정할 수 있습니다.
##
## https://www.renpy.org/doc/html/screen_special.html#preferences

screen preferences():

    tag menu

    use game_menu(_("환경설정"), scroll="viewport"):

        vbox:

            hbox:
                box_wrap True

                if renpy.variant("pc") or renpy.variant("web"):

                    vbox:
                        style_prefix "radio"
                        label _("화면 모드")
                        textbutton _("창 화면") action Preference("display", "window")
                        textbutton _("전체 화면") action Preference("display", "fullscreen")

                vbox:
                    style_prefix "check"
                    label _("넘기기")
                    textbutton _("읽지 않은 지문") action Preference("skip", "toggle")
                    textbutton _("선택지 이후") action Preference("after choices", "toggle")
                    textbutton _("화면 전환 효과") action InvertSelected(Preference("transitions", "toggle"))

                ## "radio_pref" 나 "check_pref" 를 추가하여 그 외에도 환경설정
                ## 항목을 추가할 수 있습니다.

            null height (4 * gui.pref_spacing)

            hbox:
                style_prefix "slider"
                box_wrap True

                vbox:

                    #label _("텍스트 속도")

                    #bar value Preference("text speed")

                    label _("자동 진행 시간")

                    bar value Preference("auto-forward time")

                vbox:

                    if config.has_music:
                        label _("배경음 음량")

                        hbox:
                            bar value Preference("music volume")

                    if config.has_sound:

                        label _("효과음 음량")

                        hbox:
                            bar value Preference("sound volume")

                            if config.sample_sound:
                                textbutton _("테스트") action Play("sound", config.sample_sound)


                    if config.has_voice:
                        label _("음성 음량")

                        hbox:
                            bar value Preference("voice volume")

                            if config.sample_voice:
                                textbutton _("테스트") action Play("voice", config.sample_voice)

                    if config.has_music or config.has_sound or config.has_voice:
                        null height gui.pref_spacing

                        textbutton _("모두 음소거"):
                            action Preference("all mute", "toggle")
                            style "mute_all_button"


style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 2

style pref_label_text:
    yalign 1.0

style pref_vbox:
    xsize 225

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.text_properties("radio_button")

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.text_properties("check_button")

style slider_slider:
    xsize 350

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 10

style slider_button_text:
    properties gui.text_properties("slider_button")

style slider_vbox:
    xsize 450


## History 스크린 #################################################################
##
## 지난 대사록을 출력합니다. _history_list 에 저장된 대사 기록을 확인합니다.
##
## https://www.renpy.org/doc/html/history.html

screen history():

    tag menu

    ## 이 스크린은 내용이 아주 많을 수 있으므로 prediction을 끕니다.
    predict False

    use game_menu(_("대사록"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0, spacing=gui.history_spacing):

        style_prefix "history"

        for h in _history_list:

            window:

                ## history_height 이 None일 경우 레이아웃이 틀어지지 않게 합니
                ## 다.
                has fixed:
                    yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False

                        ## 화자 Character에 화자 색깔이 지정되어 있으면 불러옵니
                        ## 다.
                        if "color" in h.who_args:
                            text_color h.who_args["color"]

                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                text what:
                    substitute False

        if not _history_list:
            label _("대사가 없습니다.")


## 이것은 대사록 화면에 표시할 수 있는 태그를 결정합니다.

define gui.history_allow_tags = { "alt", "noalt", "rt", "rb", "art" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos gui.history_name_ypos
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    textalign gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos gui.history_text_ypos
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    textalign gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5


## Help 스크린 ####################################################################
##
## 입력장치의 기능을 설명합니다. 각 입력장치별 설정은 keyboard_help, mouse_help,
## gamepad_help 스크린을 각각 불러와서 출력합니다.

screen help():

    tag menu

    default device = "keyboard"

    use game_menu(_("조작방법"), scroll="viewport"):

        style_prefix "help"

        vbox:
            spacing 15

            hbox:

                textbutton _("키보드") action SetScreenVariable("device", "keyboard")
                textbutton _("마우스") action SetScreenVariable("device", "mouse")

                if GamepadExists():
                    textbutton _("게임패드") action SetScreenVariable("device", "gamepad")

            if device == "keyboard":
                use keyboard_help
            elif device == "mouse":
                use mouse_help
            elif device == "gamepad":
                use gamepad_help


screen keyboard_help():

    hbox:
        label _("엔터(Enter)")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("스페이스(Space)")
        text _("대사를 진행하되 선택지는 선택하지 않음.")

    hbox:
        label _("화살표 키")
        text _("UI 이동.")

    hbox:
        label _("이스케이프(Esc)")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("컨트롤(Ctrl)")
        text _("누르고 있는 동안 대사를 스킵.")

    hbox:
        label _("탭(Tab)")
        text _("대사 스킵 토글.")

    hbox:
        label _("페이지 업(Page Up)")
        text _("이전 대사로 롤백.")

    hbox:
        label _("페이지 다운(Page Down)")
        text _("이후 대사로 롤포워드.")

    hbox:
        label "H"
        text _("UI를 숨김.")

    hbox:
        label "S"
        text _("스크린샷 저장.")

    hbox:
        label "V"
        text _("{a=https://www.renpy.org/l/voicing}대사 읽어주기 기능{/a} 토글.")

    hbox:
        label "Shift+A"
        text _("접근성 메뉴를 엽니다.")


screen mouse_help():

    hbox:
        label _("클릭")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("가운데 버튼이나 휠버튼 클릭")
        text _("UI를 숨김.")

    hbox:
        label _("우클릭")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("휠 위로")
        text _("이전 대사로 롤백.")

    hbox:
        label _("휠 아래로")
        text _("이후 대사로 롤포워드.")


screen gamepad_help():

    hbox:
        label _("오른쪽 트리거(RT)\nA버튼/아래 버튼")
        text _("대사 진행 및 UI (선택지 포함) 선택.")

    hbox:
        label _("왼쪽 트리거\n왼쪽 어깨")
        text _("이전 대사로 롤백.")

    hbox:
        label _("오른쪽 범퍼(RB)")
        text _("이후 대사로 롤포워드.")

    hbox:
        label _("D-Pad, 아날로그 스틱")
        text _("UI 이동.")

    hbox:
        label _("Start, Guide, B/Right Button")
        text _("게임 메뉴 불러옴.")

    hbox:
        label _("Y버튼/위 버튼")
        text _("UI를 숨김.")

    textbutton _("조정") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 8

style help_button_text:
    properties gui.text_properties("help_button")

style help_label:
    xsize 250
    right_padding 20

style help_label_text:
    size gui.text_size
    xalign 1.0
    textalign 1.0



################################################################################
## 그 외 스크린
################################################################################


## Confirm 스크린 #################################################################
##
## 게임 입력 관련 예/아니오 질문을 플레이어에게 할 때 이 스크린을 표시합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#confirm

screen confirm(message, yes_action, no_action):

    ## 이 스크린이 출력 중일 때 다른 스크린과 상호작용할 수 없게 합니다.
    modal True

    zorder 200

    style_prefix "confirm"

    add "gui/overlay/confirm.png"

    frame:

        vbox:
            xalign .5
            yalign .5
            spacing 30

            label _(message):
                style "confirm_prompt"
                xalign 0.5

            hbox:
                xalign 0.5
                spacing 100

                textbutton _("네") action yes_action
                textbutton _("아니오") action no_action

    ## 우클릭과 esc는 '아니오'를 입력하는 것과 같습니다.
    key "game_menu" action no_action


style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    background Frame([ "gui/confirm_frame.png", "gui/frame.png"], gui.confirm_frame_borders, tile=gui.frame_tile)
    padding gui.confirm_frame_borders.padding
    xalign .5
    yalign .5

style confirm_prompt_text:
    textalign 0.5
    layout "subtitle"

style confirm_button:
    properties gui.button_properties("confirm_button")

style confirm_button_text:
    properties gui.text_properties("confirm_button")


## Skip indicator 스크린 ##########################################################
##
## Skip_indicator 스크린은 스킵 중일 때 "스킵 중"을 표시하기 위해 출력됩니다.
##
## https://www.renpy.org/doc/html/screen_special.html#skip-indicator

screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:

        hbox:
            spacing 6

            text _("넘기는 중")

            text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"


## 이 transform으로 화살표를 순서대로 페이드인/페이드아웃합니다.
transform delayed_blink(delay, cycle):
    alpha .5

    pause delay

    block:
        linear .2 alpha 1.0
        pause .2
        linear .2 alpha 0.5
        pause (cycle - .4)
        repeat


style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    ypos gui.skip_ypos
    background Frame("gui/skip.png", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding

style skip_text:
    size gui.notify_text_size

style skip_triangle:
    ## BLACK RIGHT-POINTING SMALL TRIANGLE 글리프가 있는 글꼴을 사용해야 합니다.
    font "DejaVuSans.ttf"


## Notify 스크린 ##################################################################
##
## Notify 스크린으로 플레이어에게 메시지를 출력합니다. (예를 들어 '퀵세이브 완
## 료'나 '스크린샷 저장 완료')
##
## https://www.renpy.org/doc/html/screen_special.html#notify-screen

screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    ypos gui.notify_ypos

    background Frame("gui/notify.png", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding

style notify_text:
    properties gui.text_properties("notify")


## NVL 스크린 #####################################################################
##
## NVL모드 대사와 선택지를 출력합니다.
##
## https://www.renpy.org/doc/html/screen_special.html#nvl


screen nvl(dialogue, items=None):

    window:
        style "nvl_window"

        has vbox:
            spacing gui.nvl_spacing

        ## vpgrid나 vbox 내에 대사를 출력합니다.
        if gui.nvl_height:

            vpgrid:
                cols 1
                yinitial 1.0

                use nvl_dialogue(dialogue)

        else:

            use nvl_dialogue(dialogue)

        ## 주어진 경우 메뉴를 표시합니다. config.narrator_menu가 True로 설정된
        ## 경우 메뉴가 잘못 표시될 수 있습니다.
        for i in items:

            textbutton i.caption:
                action i.action
                style "nvl_button"

    add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            fixed:
                yfit gui.nvl_height is None

                if d.who is not None:

                    text d.who:
                        id d.who_id

                text d.what:
                    id d.what_id


## 동시에 출력될 수 있는 NVL 대사의 최대치를 조정합니다.
define config.nvl_list_length = gui.nvl_list_length

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    textalign gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    textalign gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    textalign gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.text_properties("nvl_button")


## Bubble screen ###############################################################
##
## 말풍선 화면은 말풍선을 사용할 때 플레이어에게 대화를 표시하는 데 사용됩니다.
## 말풍선 화면은 말풍선 화면과 동일한 매개변수를 사용하며, "what" 아이디로 표시
## 가능 항목을 생성해야 하며, "namebox", "who", "window" 아이디로 표시 가능 항목
## 을 생성할 수 있습니다.
##
## https://www.renpy.org/doc/html/bubble.html#bubble-screen

screen bubble(who, what):
    style_prefix "bubble"

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "bubble_namebox"

                text who:
                    id "who"

        text what:
            id "what"

style bubble_window is empty
style bubble_namebox is empty
style bubble_who is default
style bubble_what is default

style bubble_window:
    xpadding 30
    top_padding 5
    bottom_padding 5

style bubble_namebox:
    xalign 0.5

style bubble_who:
    xalign 0.5
    textalign 0.5
    color "#000"

style bubble_what:
    align (0.5, 0.5)
    text_align 0.5
    layout "subtitle"
    color "#000"

define bubble.frame = Frame("gui/bubble.png", 55, 55, 55, 95)
define bubble.thoughtframe = Frame("gui/thoughtbubble.png", 55, 55, 55, 55)

define bubble.properties = {
    "bottom_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "bottom_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "top_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "top_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "thought" : {
        "window_background" : bubble.thoughtframe,
    }
}

define bubble.expand_area = {
    "bottom_left" : (0, 0, 0, 22),
    "bottom_right" : (0, 0, 0, 22),
    "top_left" : (0, 22, 0, 0),
    "top_right" : (0, 22, 0, 0),
    "thought" : (0, 0, 0, 0),
}



################################################################################
## 모바일 버전
################################################################################

style pref_vbox:
    variant "medium"
    xsize 450

## 마우스가 없고 화면이 작을 가능성이 높으므로, 퀵메뉴 버튼의 크기를 키우고 가짓
## 수를 줄입니다.
screen quick_menu():
    variant "touch"

    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("되감기") action Rollback()
            textbutton _("넘기기") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("자동진행") action Preference("auto-forward", "toggle")
            textbutton _("메뉴") action ShowMenu()


style window:
    variant "small"
    background "gui/phone/textbox.png"

style radio_button:
    variant "small"
    foreground "gui/phone/button/radio_[prefix_]foreground.png"

style check_button:
    variant "small"
    foreground "gui/phone/button/check_[prefix_]foreground.png"

style nvl_window:
    variant "small"
    background "gui/phone/nvl.png"

style main_menu_frame:
    variant "small"
    background "gui/phone/overlay/main_menu.png"

style game_menu_outer_frame:
    variant "small"
    background "gui/phone/overlay/game_menu.png"

style game_menu_navigation_frame:
    variant "small"
    xsize 340

style game_menu_content_frame:
    variant "small"
    top_margin 0

style pref_vbox:
    variant "small"
    xsize 400

style bar:
    variant "small"
    ysize gui.bar_size
    left_bar Frame("gui/phone/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/phone/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    variant "small"
    xsize gui.bar_size
    top_bar Frame("gui/phone/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/phone/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    variant "small"
    ysize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    variant "small"
    xsize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    variant "small"
    ysize gui.slider_size
    base_bar Frame("gui/phone/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/horizontal_[prefix_]thumb.png"

style vslider:
    variant "small"
    xsize gui.slider_size
    base_bar Frame("gui/phone/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/vertical_[prefix_]thumb.png"

style slider_vbox:
    variant "small"
    xsize None

style slider_slider:
    variant "small"
    xsize 600
