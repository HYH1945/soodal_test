#type: ignore
# 이 파일에 게임 스크립트를 입력합니다.


# image 문을 사용해 이미지를 정의합니다.
# image eileen happy = "eileen_happy.png"

# 게임에서 사용할 캐릭터를 정의합니다.
define e = Character('황영하', color="#c8ffc8")
define ch_miku = Character('Test', color = "#c8ffc8")


define narrator = Character(None, ctc="ctc_blink", color = "#aaaaaa", what_slow_cps = 30)

default temp_player_name = ""
default player_name = "경붕이" #default name
define ch_player = Character("[player_name]", ctc="ctc_blink", color = "#ffe466", what_slow_cps = 30)

define ch_soodal = Character("달수영", ctc="ctc_blink", color = "#ffe09f", what_slow_cps = 30)
define ch_heron = Character("갈희설", ctc="ctc_blink", color = "#99b5e5", what_slow_cps = 30)
define ch_heron_letter = Character("갈희설", ctc="ctc_blink", color = "#99b5e5", what_slow_cps = 30, what_font = "fonts/NanumPen.ttf", what_size = 50)
define ch_turtle = Character("귀 연", ctc="ctc_blink", color = "#99cb94", what_slow_cps = 15)
define ch_banwoo = Character("반우", ctc="ctc_blink", color = "#ff7777", what_slow_cps = 30)
define ch_banwoo_imagination = Character("상상 속 반우", ctc="ctc_blink", color = "#ff7777", what_slow_cps = 30)

define ch_unknown = Character("???", ctc="ctc_blink", color = "#ffffff", what_slow_cps = 30)



image bg_test = "bg/test2.jpg"
image bg_jido = im.Scale("bg/jido.jpg", config.screen_width, config.screen_height)
image bg_chungdam = im.Scale("bg/chungdam.jpg", config.screen_width, config.screen_height) # 이미지 비율 유지
image bg_library_inside= im.Scale("bg/library_inside.jpg", config.screen_width, config.screen_height)
image bg_library_outside = im.Scale("bg/library_outside.jpg", config.screen_width, config.screen_height)
#image bg_gong_cafeteria = im.Scale("bg/library_outside.jpg", config.screen_width, config.screen_height)
image bg_bbqrestaurant = im.Scale("bg/bbqrestaurant_nopeople.png", config.screen_width, config.screen_height)
image bg_bbqrestaurant_people = im.Scale("bg/bbqrestaurant.png", config.screen_width, config.screen_height)

image bg_kkutso = im.Scale("bg/kkutso_nopeople.png", config.screen_width, config.screen_height)
image bg_kkutso_people = im.Scale("bg/kkutso.png", config.screen_width, config.screen_height)

image bg_bbqrestaurant_cutscene = im.Scale("bg/bbqrestaurant_cutscene.png", config.screen_width, config.screen_height)

image bg_studycafe = im.Scale("bg/studycafe.png", config.screen_width, config.screen_height)
image bg_studycafe_front = im.Scale("bg/studycafe_front.png", config.screen_width, config.screen_height)

image bg_centralroad = im.Scale("bg/centralroad.png", config.screen_width, config.screen_height)
image bg_centralroad_night = im.Scale("bg/centralroad_night.png", config.screen_width, config.screen_height)
image bg_centralroad2 = im.Scale("bg/centralroad2.png", config.screen_width, config.screen_height)

image bg_lecture_room = im.Scale("bg/lecture_nopeople.png", config.screen_width, config.screen_height)
image bg_lecture_room_people = im.Scale("bg/lecture.png", config.screen_width, config.screen_height)

image bg_ilchungdam = im.Scale("bg/ilchungdam.png", config.screen_width, config.screen_height)
image bg_ilchungdam_night = im.Scale("bg/ilchungdam_night.png", config.screen_width, config.screen_height)

image bg_zidomot = im.Scale("bg/zidomot.png", config.screen_width, config.screen_height)
image bg_zidomot_night = im.Scale("bg/zidomot_night.png", config.screen_width, config.screen_height)

image bg_flower_square = im.Scale("bg/flower_square.png", config.screen_width, config.screen_height)

image bg_club_room = im.Scale("bg/clubroom.png", config.screen_width, config.screen_height)

image bg_it_1 = im.Scale("bg/it_1.png", config.screen_width, config.screen_height)

image bg_black = im.Scale("bg/black.png", config.screen_width, config.screen_height)

image bg_picnic = im.Scale("bg/flower_square.png", config.screen_width, config.screen_height)

image bg_sincheonflood = im.Scale("bg/sincheonflood.jpg", config.screen_width, config.screen_height)
image bg_collegebuilding = im.Scale("bg/collegebuilding.jpg", config.screen_width, config.screen_height)
image bg_collegebuilding_raining = im.Scale("bg/collegebuilding_raining.jpg", config.screen_width, config.screen_height)




image cutscene_otter_1 = im.Scale("scene/cutscene_otter_1.png", config.screen_width, config.screen_height)
image cutscene_otter_2 = im.Scale("scene/cutscene_otter_2.png", config.screen_width, config.screen_height)
image cutscene_otter_3 = im.Scale("scene/cutscene_otter_3.png", config.screen_width, config.screen_height)
image cutscene_otter_4 = im.Scale("scene/cutscene_otter_4.png", config.screen_width, config.screen_height)
image cutscene_otter_5 = im.Scale("scene/cutscene_otter_5.png", config.screen_width, config.screen_height)
image cutscene_otter_6 = im.Scale("scene/cutscene_otter_6.png", config.screen_width, config.screen_height)



init python:
    config.custom_text_tags["shake"] = (lambda v, d: "{=shake}" , lambda v: "{/=shake}")

image scg_miku:

    im.FactorScale("character/test.png", 0.5)
    xalign 0.1
    yalign 0.6

image scg_banwoo:
    im.FactorScale("character/banwoo.png", 1.3)
    xalign 0.5
    yalign 0.5

image scg_soodal_animal:
    im.FactorScale("character/heron_animal.png", 1.15)
    xalign 0.5
    yalign 0.5



image scg_suyeong_normal:
    im.FactorScale("character/soodal/suyeong_normal.png", 1)
    xalign 0.5
    ypos 720
image scg_suyeong_confused:
    im.FactorScale("character/soodal/suyeong_confused.png", 1)
    xalign 0.5
    ypos 720
image scg_suyeong_mumuring:
    im.FactorScale("character/soodal/suyeong_mumuring.png", 1)
    xalign 0.5
    ypos 720    
image scg_suyeong_fun:
    im.FactorScale("character/soodal/suyeong_fun.png", 1)
    xalign 0.5
    ypos 720
image scg_suyeong_worried:
    im.FactorScale("character/soodal/suyeong_worried.png", 1)
    xalign 0.5
    ypos 720

image scg_suyeongcafe_normal:
    im.FactorScale("character/soodal/suyeongcafe_normal.png", 1)
    xalign 0.5
    ypos 720




image scg_heron:
    im.FactorScale("character/heron_animal.png", 1)
    xalign 0.3
    yalign 0.75

image scg_heesul_normal:
    im.FactorScale("character/heron/heesul_normal.png", 1)
    xalign 0.5
    ypos 720
image scg_heesul_blush:
    im.FactorScale("character/heron/heesul_blush.png", 1)
    xalign 0.5
image scg_heesul_smile:
    im.FactorScale("character/heron/heesul_smile.png", 1)
    xalign 0.5



image scg_turtle:
    im.FactorScale("character/turtle_animal.png", 1)
    xalign 0.5
    yalign 0.7
image scg_yun_normal:
    im.FactorScale("character/turtle/yun_normal.png", 1)
    ypos 760
image scg_yun_confused:
    im.FactorScale("character/turtle/yun_confused.png", 1)
    ypos 760
image scg_yun_mumuring:
    im.FactorScale("character/turtle/yun_mumuring.png", 1)
    ypos 760
image scg_yun_shouting:
    im.FactorScale("character/turtle/yun_shouting.png", 1)
    ypos 760
image scg_yun_surprised:
    im.FactorScale("character/turtle/yun_surprised.png", 1)
    ypos 760
image scg_yun_smiling:
    im.FactorScale("character/turtle/yun_smiling.png", 1)
    ypos 760
image scg_yun_glasses_normal:
    im.FactorScale("character/turtle/yunglasses_normal.png", 1)
    ypos 760
image scg_yun_glasses_shouting:
    im.FactorScale("character/turtle/yunglasses_shouting.png", 1)
    ypos 760
image scg_yun_glasses_confused:
    im.FactorScale("character/turtle/yunglasses_confused.png", 1)
    ypos 760
image scg_yun_glasses_surprised:
    im.FactorScale("character/turtle/yunglasses_surprised.png", 1)
    ypos 760

image scg_player_music:
    im.FactorScale("character/player/player_music.png", 1)
    ypos 740

image scg_player_kakaotalk1:
    im.FactorScale("character/player/palyer_kakaotalk1.png", 1)
    ypos 740

image scg_player_kakaotalk2:
    im.FactorScale("character/player/player_kakaotalk2.png", 1)
    ypos 740

image scg_player_call:
    im.FactorScale("character/player/player_call.png", 1)
    ypos 740



define sound_cheers = "audio/effect/건배.mp3"
define sound_pouring = "audio/effect/소주잔따르기.mp3"
define sound_remote_control = "audio/effect/띡.mp3"
define sound_rain = "audio/effect/rain.mp3"
define sound_wooden_chair = "audio/effect/나무의자.mp3"
define sound_doorbell = "audio/effect/도어벨.mp3"
define sound_rock_music = "audio/effect/락음악.mp3"
define sound_earthquake = "audio/effect/무너지는소리.mp3"
define sound_chewing_cookie = "audio/effect/오독오독.mp3"
define sound_phone_vibrate = "audio/effect/진동소리.mp3"
define sound_phone_callexit = "audio/effect/전화끊는소리.mp3"
define sound_waterfall = "audio/effect/폭포소리.mp3"
define sound_walk_slipper = "audio/effect/발자국_슬리퍼.mp3"
define sound_walk_gravel = "audio/effect/발자국_자갈.mp3"
define sound_water_splash = "audio/effect/풍덩소리.wav"


define sound_ui_pop = "audio/effect/ui/pop.mp3"
define sound_ui_pop2 = "audio/effect/ui/pop2.mp3"
define sound_ui_ring = "audio/effect/ui/ring.mp3"

# test용 간단한 미니게임
screen apple_game():
    frame:
        xalign 0.5
        yalign 0.5
        vbox:
            spacing 20
            text "사과를 클릭하세요"
            imagebutton:
                idle "Character/test.png"
                hover "Character/test2.png"
                action Return("apple_clicked")


#########효과##############
transform bounce:
    linear 0.15 yoffset -70
    linear 0.15 yoffset 0

transform move_right:
    xalign 0.5
    linear 0.52 xpos 300
transform transparent_50:
    alpha 0.5

transform transparent_25:
    alpha 0.25

transform transparent_75:
    alpha 0.75

##########################

define total_chapters = 10
default current_progress = 0

default persistent.current_clear = [False, False, False, False, False, False, False, False, False, False]
default persistent.current_chapter = 0





########################## 게임
default gauge = 0.5     # 게이지 (1.0 = 100%)
default gauge_running = False
default gauge_result = None
define gauge_min = 0.0
define gauge_max = 1.0
define gauge_decay = 0.01      # 게이지 자동 감소 속도 (프레임당 약 1%)
define gauge_increase = 0.03   # 스페이스바 입력 시 증가량
define gauge_time = 5.0       # 게임 제한 시간
define gauge_success_min = 0.4 # 성공 최소 범위
define gauge_success_max = 0.6 # 성공 최대 범위

screen gauge_minigame():
    frame:
        align (0.5, 0.2)
        text "SPACE" size 30
        

    # 게이지 표시 바
    bar value gauge range 1.0 xmaximum 600 ymaximum 40 align (0.5, 0.3)

    # 현재 게이지 % 표시
    #text "버텨라" align (0.5, 0.1) size 40
    text "[int(gauge * 100)]%" align (0.5, 0.4) size 30

    # 타이머 표시
    text "남은 시간: [int(timer_left)]초" align (0.5, 0.5) size 30

    key "K_SPACE" action Function(increase_gauge)

    if not gauge_running:
        # 게임 종료 시 결과 표시
        if gauge_result is not None:
            if gauge_result:
                text "성공!" align (0.5, 0.6) size 40 color "#00ff00"
            else:
                text "실패!" align (0.5, 0.6) size 40 color "#ff0000"

# 게이지 증가 함수
init python:
    def increase_gauge():
        global gauge
        if gauge_running:
            gauge = min(gauge + gauge_increase, gauge_max)

label gauge_minigame_label:
    $ gauge = 0.5
    $ gauge_running = True
    $ gauge_result = None
    $ timer_left = gauge_time

    show screen gauge_minigame

    while timer_left > 0:
        $ renpy.pause(0.1)
        # 시간에 따라 감소량이 증가 (지수 증가 방식)
        $ decay = gauge_decay * (1.0 + 2.0 * (1 - timer_left / gauge_time) ** 2)
        $ gauge = max(gauge - decay, gauge_min)
        $ timer_left -= 0.1

    $ gauge_running = False

    if gauge_success_min <= gauge <= gauge_success_max:
        $ gauge_result = True
    else:
        $ gauge_result = False

    return


##########################




label progress:


    call screen chapter_progress with fade
    return


# 여기에서부터 게임이 시작합니다.
label start:
    

    call screen input_name with fade
    $ player_name = player_name.strip()   # 혹시 모를 공백 제거
    
    #scene bgssa_test with fade
    #$ ch_miku = Character("Test", what_slow_cps = 10, interact=True)
    #show scg_miku with dissolve

    #scene bg_it_1 with fade
    #show scg_turtle_human with dissolve
    #hide scg_turtle_human with dissolve
    #show scg_heron_human at move_right with dissolve 
    #show scg_turtle_human with dissolve

    hide screen gauge_minigame with fade
    call episode_gaegang_soodal
    call episode_gaegang_heron
    call episode_gaegang_turtle

    call episode_spring_soodal
    call episode_spring_heron
    call episode_spring_turtle
    #call episode_turtle_lunchdate
    #call episode_heron_midtermS
    #--------------------apple game-----------------------------#
    
    # $ result = renpy.call_screen("apple_game")

    # if result == "apple_clicked":
    #     ch_miku "잘했어요! 클릭 성공입니다."
    
    #--------------------apple game-----------------------------#

    return 

image bg_progress = im.Scale("bg/black.png", config.screen_width, config.screen_height)

label cutscene_intro:

    # 컷신 시작 전 설정
    $ _skipping = False  # 스킵 방지
    $ _rollback = False  # 롤백 방지
    $ renpy.block_rollback()
    $ renpy.pause(0.1, hard=True)

    $ _game_menu_screen = None  # ESC 메뉴 비활성화

    # 저장/기록 메뉴 임시 비활성화

    window hide
    scene black with fade

    # 컷신 슬라이드
    show cutscene_otter_1 with dissolve
    $ renpy.pause(2.5, hard=True)


    # 컷신 종료 후 설정 원상복구
    $ _game_menu_screen = "game_menu"
    $ _skipping = True
    $ _rollback = True

    return


label episode_gaegang_soodal:

    #배경 : 개강총회3
    scene bg_centralroad_night with fade
    
    ch_player "(학교에 복학한 지도 어느덧 한 주가 다 되어간다.)"
    ch_player "(시간이 정말 빠르구나 싶다가도 복학생의 시간이 이렇게 흘러간다는 것에 눈물이 조금 흐른다.)"
    ch_player "(오늘은 대망의 개강총회..!)"
    ch_player "(복학생으로서 참여한다는 게 약간 머시기 하지만 코노 [ch_player]에게는 유메가 아루..!)"
    ch_player "(이번에야말로 친구를 잔뜩 사귀고 알파메일이 되어서 행복한 캠퍼스 라이프를 보내는 거야..!)"

    scene bg_kkutso_people with fade
    ch_player "(이런 생각을 하고 있지만 정작 현실은 지금까지 아무에게도 말 못 걸고 혼자 구석에서 조용히 박혀있는 중이다..)"

    ch_player "(심지어 우리 테이블은 대충 ㅈㄴ 조용하다는 불만)"
    ch_player "(…근데 왜 나 말고 다른 사람들도 조용하지)"
    ch_player "(아니, 왜 아무도 말을 안 해! 놀자고 좀!!!)"
    ch_player "(젠장 안 되겠다.)"
    ch_player "(우리 배는 망했다.)"
    ch_player "(배를 버리라 선원들!!!)"
    ch_player "(우리는 다른 테이블로 향한다!!)"
    ch_player "(배를 버려라!!!)"
    ch_player "(좋았어. 자연스럽게 다른 테이블로 향하는 거야.)"
    ch_player "(전혀 동요하지 말자, [ch_player]. 넌 할 수 있어.)"

    ch_player "(어디 자리가... 마침 옆에 빈자리가 보인다.)"
    ch_player "(테이블에 누가 앉아있는지 모르겠지만 일단 저쪽으로...!)"

    #play sound 철푸덕덕
    #play sound sound_wooden_chair
    ch_player "(빈자리에 앉았다.)"
    ch_player "근데 철푸덕이 뭐야. 이상해! 벌써 망했어!"
    ch_player "아니야. 아직은 기회가 있을 거야!"
    ch_player "(자연스럽게 인사를 해 보자. 최대한 자연스럽게. 원래 여기 있던 사람처럼...)"

    ch_player "아... 안녕?"
    ch_player "(누구인지는 모르겠지만 제발 인사를 받아줬으면...)"

    define ch_unknown = Character("???", ctc="ctc_blink", color = "#8d5a18", what_slow_cps = 30)
    ch_unknown "어...! 안녕?"

    ch_player "(뭔가 익숙한 목소리다.)"
    ch_player "(누구지...? 복학 후에 유일하게 대화한 여자는 교수님밖에 없는데...?)"

    #call cutscene_intro

    window hide
    $ renpy.pause(0.2)
    $ renpy.pause(0.2)
    $ renpy.pause(0.2)
    show cutscene_otter_1 with Pixellate(1, 4)
    $ renpy.pause(100)

    hide cutscene_otter_1 with Pixellate(1, 4)
    $ renpy.pause(0.2)

    show scg_suyeong_normal zorder 4 with dissolve 
    ch_soodal "오랜만이다...! 잘 지냈어?"
    ch_player "(오랜만...? 오래전에 알았던 여성은... 아...! 설마...!)"

    ch_player "너... 설마 달수영..?"
    ch_soodal "맞아!!! 알아보는구나!! 여기서 다 보네!"

    show bg_black behind scg_suyeong_normal at transparent_75 with dissolve
    narrator "(달수영, 나의 중학교 동창이자 같은 과 동기다.)"
    narrator "(같은 과 동기라고 했지만, 이래저래 여러 사정으로 그녀는 내가 동기인 것을 모른다.)"
    narrator "(전공이 다르다던가, 다른 그룹에 있다던가, 내가 그냥 말을 못 걸었다거나... 대충 그런 이유다.)"
    hide bg_black with dissolve
    ch_player "오... 오랜만이네... 잘 지냈어...?"
    ch_soodal "나야 잘 지냈지! 근데 네가 어떻게 여기 있어? 네가.. 재수했었나...?"

    narrator "(어떻게 대답을 하지? 사실대로 말해야 하나..? 대답을 어떻ㄱ..)"

    ch_soodal "[ch_player]? 왜 그래?"
    ch_player "ㅇ..아..아니야.."
    ch_player "(모르겠다. 사실대로 말하자.)"

    ch_player "나... 사실 이 대학 다녔었어..."
    ch_soodal "어??? 진짜?? 왜 몰랐지? 잠시만.. 개총에 온 거면 과도 같은 과?? 왜 처음 보는 거지?"

    ch_player "어... 그게 그.... 사정이..."
    hide scg_suyeong_normal with dissolve
    ch_player "(그때, 한 신입생이 건배사를 했다. 변명 짜내느라 죽을 뻔했는데, 덕분에 살았다!)"
    define ch_newbieman = Character("신입생", ctc="ctc_blink", what_slow_cps = 30)
    ch_newbieman "혁신!!!"
    define ch_all = Character("모두", ctc="ctc_blink",what_slow_cps = 30)
    ch_all "컴학!!!!! 짠!!!!!"
    play sound sound_cheers
    show scg_suyeong_normal with dissolve
    show scg_suyeong_normal at bounce
    ch_soodal "짠!!!!"
    ch_player "ㅉ..짜아안.."

    # 잔 이미지지

    ch_soodal "크..... 뭐 아무튼 전공이 달라서 그랬나?" 
    ch_player "ㅇ...어! 그런 거 같아 난 그.. 글솦이라서"
    ch_soodal "아 그래? 난 인컴이라서 그런가 보다! 뭐, 이제 봤으니 친하게 지내면 되는 거지!"
    ch_player "그..그래 그러면 되는..거지"
    ch_soodal "자자 일단 짠하자! 짠!"
    ch_player "짜..짠!"

    narrator "(한 잔, 두 잔 술잔이 오간다.)"
    narrator "(그간의 공백을 채우듯 추억 가득 찬 이야기가 오고 가지만, 주변 분위기는 이런 둘을 무시하며 시끄럽게 달아오른다.)"
    narrator "(주인공과 달수영 사이에 한 잔, 두 잔 술잔이 오고 간다.)"
    narrator "(술잔과 함께 추억 가득한 이야기들도 도란도란 오고 간다.)"
    narrator "(그러나 주변 분위기는 점차, 대화가 어려울 정도로 소란스럽게 달아올랐다.)"

    #play sound "murmur.ogg, 웅성웅성성"
    hide scg_suyeong_normal
    show scg_suyeong_mumuring
    ch_soodal "그래서 그때- 아.. 너무 시끄럽네.."
    ch_player "그..그러게 말 소리가 잘 안 들린다..."
    ch_soodal "우리 밖에 바람이나 쐬러 갈까?"
    ch_player "그어..그...래.."

    # 독백이 나올때
    # 1. 캐릭터 cg를 없애기
    # 2. 유지하기
    # 3. 캐릭터 cg의 밝기를 낮추거나 흐리게하기
    scene bg_centralroad_night with fade

    narrator "(이게 무슨 일일까? 오늘이 무슨 날인가? 내일의 나는 죽는 것이 아닐까?)"
    narrator "(수영이와 대화도 길게 하고, 같이 단둘이 바람 쐐러간다니...)"
    narrator "(하지만 이런 걱정이 무색하게도 우리는 정말정말정말정말 아무런 일 없이 중학생 때의 추억 이리저리 이야기했다.)"

    show scg_suyeong_normal with dissolve
    ch_soodal "어..! 방금 톡 봤는데 1차 끝이래!"
    ch_player "ㅇ..어? 진짜? 벌써..가 아니라 지금 12시구나.."
    ch_soodal "헉..! 그러네!! 난 이제 가봐야겠다."
    ch_player "그..시간이 늦었으니까 데려다줄게..!!"
    hide scg_suyeong_normal
    show scg_suyeong_mumuring
    ch_soodal "헉.. 괜찮은데..귀찮지 않아..?"
    ch_player "{size=33}ㅈ..전혀!{size=16}\ \ \ \ \ 사실 오히려 좋아..."

    ch_soodal "음... 그래도 너무 머니까.. 일청담까지만 데려다줘!"
    ch_player "일청담? 어.. 알았어.."
    
    hide scg_suyeong_mumuring with dissolve
    play sound sound_walk_slipper
    narrator "(한 마리와 한 명, 둘 다 술에 취해 비틀거리며 일청담으로 향한다.)"
    narrator "(물비린내, 그리고 바람이 기분 좋게 불어온다.)"
    narrator "(바람의 시원함과 함께 수영의 향기가 느껴진다.)"
    narrator "(수달의 냄새......)"
    narrator "(아. 정말 최고의 하루다. 정말 기분이 좋은 하루다.)"
    narrator "(그러고보니 보통 집에 간다면 버스정류장으로 가지, 왜 일청담으로 향하는지는 모르겠다.)"
    narrator "(뭐, 수영이만의 시크릿이 있다고 이해하고 별 생각 안 하기로 했다.)"

    scene bg_ilchungdam_night with fade
    narrator "(이런 저런 생각도 하고, 수영과 수다를 떨며 길을 가니 꽤나 빨리 도착했다.)"
    narrator "(아쉽게도 헤어질 시간이 왔다.)"
    show scg_suyeong_normal with dissolve
    ch_soodal "오늘은 즐거웠어! 조심히 들어가고 잘 쉬어! 내일 보자!"
    ch_player "너..너도 조심히 들어가..!"
    ch_soodal "웅! 그래!"

    hide scg_suyeong_normal with dissolve
          
    narrator "(나는 수영에게 간단한 손 인사를 했다.)"

    play sound sound_water_splash
    narrator "(그러자 갑자기 수영은 사라지고 일청담에서 퐁! 하는 물소리가 났다.)"
    narrator "(뭔 소리지? 모르겠다.)"
    narrator "(자취방에나 가자······)"

    scene bg_centralroad_night with fade
    narrator "(생각해 보니 방금 뭐라고 했지..?)"
    narrator "(내일...보..자..?)"
    narrator "(그러면 내일도 만나겠다는 소리인가?)"
    narrator "(끼야아아앗호오우!!!!)"
    narrator "(이처럼 완벽한 엔딩이 있을까.)"
    narrator "(복학 후 처음으로 내일이 기대된다….)"

    $ current_progress += 1
    $ persistent.current_clear = [True, False, False, False, False, False, False, False, False, False]
    $ persistent.current_chapter = 1

    call progress

    scene black with fade
    return

label episode_gaegang_heron:

    # 배경 : 강의실
    scene bg_lecture_room_people with fade
    ch_player "허억허억! 겨우 안 늦었네···."
    narrator "강의실에 사람이 꽉 차 있다."
    ch_player "너무 시간표를 빡빡하게 짠건가···."
    narrator "(자리를 잡을 시간이 통 안 난다···. 저기 비어있는 자리에 앉도록 하자.)"

    narrator "수군수군··"

    ch_player "시선이 느껴지는데···."

    #컷신

    narrator "옆을 보니 긴머리의 여성분이 앉아 있다."

    scene bg_black with fade

    show scg_banwoo with dissolve


    ch_banwoo_imagination "(인간 관계를 넓히는게 좋아 {size=20}좋아 {size=15}좋아···)"
    
    hide scg_banwoo with dissolve

    ch_player "(그래. 해보자.)"
    scene bg_lecture_room_people with fade
    ch_player "아··안녕하세요?"

    show scg_heesul_normal with dissolve
    ch_heron "···안녕하세요."
    ch_heron "수영이 지인이셨나요?"
    ch_player "아 네네, 반갑습니다."
    ch_heron "···네."

    ch_player "(왜이리 차가우시지··. 초면에 이름부터 묻는게 실례였나···.)"



    hide scg_heesul_normal with dissolve
    ch_player "(그리고 강의 OT 내내 갈희설과 교류는 없었다···.)"


    #교수 이미지
    define ch_prof = Character("교수님", ctc="ctc_blink", what_slow_cps = 30)
    ch_prof "이것으로 오늘 수업은 마치겠습니다. 아, 아직 짐싸지 마세요. 공지 사항이 남아 있습니다."
    ch_prof "이 수업이 또 교양이긴 하지만, 결혼과 가정이라는 과목을 듣는 다는 것은 분명 이 분야에 관심이 많이 있다는 거겠죠, 학생 분들?"
    ch_prof "제게 그 관심을 보여주시길 바랍니다."
    ch_prof "자, 첫 과제입니다. 조별 과제 형식으로 과제가 나갈 것이고요. 주제는 과연 이 시대에 결혼이 필요한 이유는 무엇일까? 입니다."
    ch_prof "조는 제가 랜덤하게 추첨하도록 하겠고요. 오늘 중으로 lms에 팀 결성 공지 올릴테니 열심히들 해보세요."

    narrator "학생들 사이에서 울분이 쏟아져 나왔다."

    define ch_extra_1 = Character("언짢아보이는 남학생",ctc="ctc_blink", what_slow_cps = 30)
    ch_extra_1 "아아, 첫 시간부터 조별과제 공지라니!"

    define ch_extra_2 = Character("숙연한 여학생",ctc="ctc_blink", what_slow_cps = 30)
    ch_extra_2 "오늘 내 팀이 무너질 예정이야···."

    ch_player "(다들 앵간히도 마음에 안 드나보다. 그래도 나름 관심있는 교양이었는데···. 조라도 잘 모이길 바래보자···.)"

    scene bg_zidomot_night with fade
    narrator "그날 저녁 9시."
    ch_player "6조··· [ch_player], 갈희설. 두 명이서 하는 것도 조별과제가 맞나?"

    define ch_prof_paper = Character("교수님의 메세지",ctc="ctc_blink", what_slow_cps = 30)
    ch_prof_paper "(두 명이서 심도 높은 토론을 하고 그 시너지를 보여주길 바랍니다.)"

    ch_player "(희설씨··· 믿을게요.)"

    # scene 전화받는 이미지
    
    play sound sound_phone_vibrate
    ch_player "아 깜짝이야!"
    show scg_player_call with moveinbottom
    ch_player "(모르는 번호가 폰 화면에 떠있다.)"

    ch_player "보이스피싱이겠지? 끊어야겠다."

    hide scg_player_call with moveoutbottom
    # scene 전화받는 이미지
    ch_player "..."
    play sound sound_phone_vibrate
    ch_player "(전화가 또 다시 울린다.)"
    show scg_player_call with moveinbottom
    ch_player "(기록을 보니 방금 전과 같은 전화번호다.)"

    hide scg_player_call with moveoutbottom
    ch_player "···여보세요?"
    ch_heron "안녕하세요 [ch_player]씨."
    ch_player "아, 희설 씨세요?"
    ch_heron "전화번호라면 수영이에게 물어봤어요."
    ch_player "그런데 어쩐일로 전화하셨어요?"
    ch_heron "학생 정보 시스템 보셨죠?"
    ch_player "네. 저도 방금 막 확인했네요."
    ch_heron "제가 할일을 빠르게 처리하는 걸 선호해서. 혹시 이번 주말에 시간 되실까요?"
    ch_player "아, 저는 시간 괜찮아요."
    ch_heron "그럼 주말에 만나는 걸로 해요. 만날 장소로 북문 앞 스벅은 어떠신가요?"
    ch_player "좋아요."
    ch_heron "그럼 주말에 뵙겠습니다."


    scene bg_black with fade
    narrator "시간이 흘러 주말이 되었다···."
    
    #배경 : 카페
    play sound sound_doorbell
    ch_player "약속 시간보다 30분이나 일찍 도착했네···. 후후·· 이 정도면 먼저 도착했겠지?"

    scene bg_studycafe_front with fade

    
    # 검은 배경, 이후 자동문 소리 삽입
    
    #scene bg_cafe
    # 화면 흔들리는 효과
    #show screen shake
    show bg_studycafe_front with vpunch
    ch_player "!"


    narrator "자동문을 열고 카페로 들어가니 갈희설이 앉아 있다."

    hide bg_studycafe_front
    scene bg_studycafe with fade
    ch_player "안녕하세요. 일찍 오셨네요?"
    show scg_heesul_normal with dissolve
    ch_heron "제가 원래 빨리 다니는 걸 선호해서. 오셨으니, 조금 더 일찍 시작해볼까요?"
    ch_player "네. 좋습니다."

    ch_heron "이건 이렇게 하는게 어떨까요?"
    ch_heron "이것만 넣으면 설득력이 떨어질 것 같은데···."
    narrator "이후 마구마구 버스 태워졌다."

    ch_heron "후···. 많이 했네요. 잠깐 쉬었다가 다시 할까요?"
    ch_player "네."
    ch_player "(다시 보니 희설 씨 외모가 상당했구나. 잘 손질된 깃털이며, 길게 늘어진 다리까지···.)"
    ch_heron "[ch_player]씨 혹시 무슨 용건이라도?"
    ch_player "아, 아니에요."
    ch_player "(예뻐서 봤다고는 절대 말 못 하지! 지난번에 시선이 쏠린 이유를 알 것도 같다···.)"

    define ch_cafestaff = Character("카페 직원", ctc="ctc_blink",what_slow_cps = 30)
    ch_cafestaff "주문하신 아이스 아메리카노 나왔습니다!"
    ch_player "음료수 가져 올게요."
    ch_heron "네."
    hide scg_heesul_normal with dissolve
    scene bg_studycafe with fade

    show scg_heesul_normal with dissolve
    ch_heron "이제 충분히 쉬었으니 다시 시작해볼까요?"
    ch_heron "[ch_player]씨는 자료 조사 더 부탁드릴게요."
    
    ch_player "네!"
    hide scg_heesul_normal with dissolve

    show scg_player_music with moveinbottom
    ch_player "(조사에는 역시 음악이지.)"
    play sound beep
    narrator "띡!"
    play sound sound_rock_music

    show bg_studycafe with hpunch
    narrator "{size=70} 끼야야야아아악!!!"
    narrator "순식간의 좌중의 이목이 우리 테이블로 쏠렸다."
    narrator "(웅성웅성)"

    hide scg_player_music with moveoutbottom
    ch_player "···."
    ch_player "죄송합니다 희설 씨. 헤드셋 연결이 안 돼있었네요···."
    show scg_heesul_blush with dissolve
    narrator "눈앞의 갈희설은 얼굴도 울그락불그락하고 머리털도 삐쭉 솟아 있었다."
    ch_player "(많이 화나신걸까···.)"
    narrator "순간 쪽팔림보다 희설 씨에게 미움 받을 수도 있다는 걱정이 더 크게 든 이유는 무엇일까."

    narrator "이후 조별과제 시간 내내 갈희설은 무언가 참는 것이 있는 것처럼 보였다."
    ch_player "(희설 씨 얼굴이 점점 빨개지는거 같은데···. 내가 너무 큰 잘못을 한걸까.)"
    hide scg_heesul_blush with dissolve

    #딸랑랑
    play sound sound_doorbell
    ch_cafestaff "다음에 또 오세요!"

    scene bg_flower_square with fade
    ch_player "···."
    ch_player "희설씨 아까 많이 화나셨나요··? 안색이 안 좋아보이시는데··. 죄송합니··"

    show scg_heesul_smile with dissolve
    ch_heron "{size=40}[ch_player] 씨도 락 좋아하세요!!!"
    ch_heron "{size=30}저는가장좋아하는밴드가뮤즈인데특히그반사회적이고음모론적인가사의내용이너무좋달까요[ch_player]씨는아까···"
    ch_player "희설 씨 숨 쉬세요 숨!"
    hide scg_heesul_smile with dissolve
    ch_player "(내 실수로 뭔가 깨우면 안될 것을 깨우고 만 것 같다···.)"
    

    $ current_progress += 1
    $ persistent.current_clear = [True, True, False, False, False, False, False, False, False, False]
    $ persistent.current_chapter = 2
    call progress
    scene black with fade
    return

transform shake_text:
    linear 0.03 xoffset -2
    linear 0.03 xoffset 2
    repeat


label episode_gaegang_turtle:

    # 배경 : 동아리 오리엔테이션 뒤풀이 : 술집
    scene bg_bbqrestaurant_people with fade
    ch_player "여기는 동아리 “현시연” 오리엔테이션 뒤풀이 현장."
    ch_player "동아리에 대한 설명을 들은 뒤, 뒤풀이를 즐기러 왔다."
    ch_player "문화를 적극적으로 즐기는 사람들이 모인 이 동아리라면,"
    ch_player "나와 같은 동료들을 사귀기에 가장 적합할 것 같아서 이번 학기에 새로 들어오게 되었다."
    ch_player "임원진들의 발표를 들어보니 나와 같은 “진짜”의 부류들인 것 같아서, 정말 마음에 들었다."
    
    #play sound 희망찬 효과음
    ch_player "여기라면, 함께 문화생활을 즐길 동료들을 사귈 수 있겠지?"

    narrator "주인공이 앉은 곳은 4인 테이블."
    narrator "주인공과 거북이 하나. 그리고 두 사람이 앉았다."
    narrator "전부 하나같이 내성적인 인상이다."
    #play sound 비극적인 효과음
    narrator "그래서 그런지 아무도 입을 열지 않았다......"

    ch_player "(뭐야, 왜 아무도 말을 안 해!)"
    ch_player "(으으, 이래서는 과 OT 때의 악몽이 되풀이될 뿐이야!)"
    ch_player "(그래, 여기라면…. 나와 같은 동족들이 모인 이곳이라면!)"
    
    #play sound 희망찬 효과음
    ch_player "(이번엔 피하지 않는다. 직접 개척이다.)"
    ch_player "저, 저희 이,,인사부터 할까요? 저, 전 컴공 [ch_player] 입니다."
    ch_player "그. 애니메이션 나는 내일의 아침밥이지만…. 아니 이건 너무 길다. \"아침점심\" 좋아해서 들어오게 되었어요!"
    ch_player "최애캐는 G인데 되게 모에하면서도 뚝감자상이라 제 스타일이라서…."
    

    
    #텍스트 흔들리는 효과
    show bg_bbqrestaurant_people with hpunch
    ch_player "{size=45}(이렇게 들어가면 너무 씹덕같잖아-!!!!!)"
    #hide bg_bbqrestaurant_people with hpunch
    #텍스트 출력 속도 빠르게
    ch_player "{cps=100}네. 아무튼그래서G를되게좋아하고있고애니메이션보는거엄청좋아합니다. 여케이쁘게나오는거는다관심있으니까 만화이야기하실사람필요하시면저꼭찾아주세요."

    show bg_bbqrestaurant_people with hpunch
    ch_player "(왜 더듬었지? 그리고 막판에 갑자기 말은 왜 빨라진거야-!!!!)"
    ch_player "(나, 왜 이렇게 사회성 없는거냐고!!!!!!!!!)"

    narrator "주인공을 이어서 다른 사람들도 자기소개를 시작한다."
    define ch_tablegirl = Character("???", ctc="ctc_blink", what_slow_cps = 30) # 테이블 여자
    ch_tablegirl "제 이름은 **이고요, 게임 좋아합니다. 파묻힌 별들....."
    define ch_tableboy = Character("??",ctc="ctc_blink", what_slow_cps = 30) # 테이블 남자
    ch_tableboy "안녕하세요. 저는 어떤 학과 다니는......"

    show scg_yun_glasses_normal with dissolve
    ch_turtle "저, 저는 인문대학 다니는 귀연이라고 하고요오......"
    ch_player "(거북이가 말한다.)"

    show bg_bbqrestaurant_people with hpunch
    ch_player "(근데 현타와서 하나도 안 들려-!!!!!!)"
    ch_player "(이름밖에 못 들었어!!!!)"
    ch_player "(근데 거북인데 이름에도 귀자가 들어가네.)"

    hide scg_yun_glasses_normal with dissolve
    narrator "주인공의 속이 심란한 와중에, 주인공의 앞에 앉은 거북이의 시선이 무언가 심상치 않다. 어떤 의미일까?"
    narrator "하지만 눈치 없는 주인공은, 거북이가 자신을 묘하게 보고 있다는 것조차 눈치채지 못한다......"

    
    #텍스트 흔들리는 효과
    ch_player "(으아아, 나 너무 뻣뻣해)"
    ch_player "(일단 얼른 술을 마셔서 긴장을 풀자!!)"
    narrator "(소주병을 들어 잔을 채우려고 한다.)"
    narrator "그러자 거북이 귀연이 주인공을 향해 팔을 뻗는다."

    show scg_yun_glasses_normal with dissolve
    ch_turtle "저, 저 주세요."
    ch_player "엥? 아. 감사합니다."
    narrator "(주인공이 거북이에게 술을 받는다.)"
    ch_player "잔 비었네. 나도 따라줄께요."

    play sound sound_pouring
    narrator "주인공이 귀연에게 소주병을 건네받는다. 주인공이 귀연의 잔을 채워준다."

    # 의아한 효과음? 굳이
    ch_player "(거북이가 술 먹어도 되는 거 맞나?)"
    ch_player "(거북이랑 맞술이라니, 뭔 개꿈....... 아니, 거북이꿈이 다 있네.)"
    ch_player "(어, 근데 거북이꿈이 금전운 아니였나? 아싸, 로또사야지.)"
    ch_player "(근데 아까 새내기랬나? 술자리 몇 번 안 와봤나? 되게 긴장했네. 귀가 막 빨갛다.)"
    ch_turtle "우, 우리 짠 할까요.......?"
    ch_player "좋아요. 건배!"
    play sound sound_cheers
    narrator "비슷한 관심사를 가진 사람들을 만나서 신난건지, 아니면 단순 술기운에 흥이 난 것인지는 모르겠지만 주인공이 나서서 건배사를 외쳤다."
    narrator "평소 주인공이라면 상상하기 힘든 일이었다."
    ch_turtle "건배!"
    hide scg_yun_glasses_normal with dissolve
    play sound sound_cheers
    narrator "잔이 서로 부딪히는 소리가 났다. 그 뒤로도 몇 번의 건배가 더 있었다."
    narrator "시간이 흘러서인지, 알코울이 들어가서인지 분위기도 점차 화기애애하게 무르익어갔다."
    narrator "분위기가 풀리자 자연스럽게 많은 이야기가 오고갔다."
    narrator "주인공이 대학교 들어온 뒤로 이런 편안한 모임은 아주 오랜만이였다."
    narrator "마지막으로 술자리가 재미있던 적은 언제였지?"
    narrator "......"
    narrator "......어쩌면 처음일지도 모르겠다."
    ch_player "(말이 너무 잘 통해! 신난다!)"
    narrator "아주 오래간만의, 혹은 처음으로 즐거운 술자리에 신이 난 주인공은 마구 이야기를 한다."
    define ch_staff = Character("임원",ctc="ctc_blink",what_slow_cps = 30)
    ch_staff "저희 이제 1차 슬슬 마무리할게요. 가실 분은 가시고 2차 가실 분은 2차 가실께요~"

    show scg_yun_glasses_normal with dissolve
    ch_turtle "선배. 2차 가죠?"
    ch_player "으, 으응? 아니. 내일 일정이 있어서 들어가려고."
    ch_turtle "저 같이 더 놀고 싶은데…. 택시 타면 안 돼요?"
    narrator "(귀연이 주인공의 눈을 빤히 보며 말한다.)"
    ch_player "(하이씨, 그냥 2차 갈까?)"
    narrator "하지만 그럴 순 없었다."
    narrator "내일 아침 오전 9시, 애니메이션 나는 내일의 아침밥이지만 당신은 오늘의 저녁밥입니다만? ~끼니를 챙겨 먹는 것은 아주 중요해~의 피규어 예약판매가 열리기 때문이었다."
    ch_player "(아쉽지만, 내일은 G짱의 피규어를 꼭 손에 넣어야 하니까 오늘은 시마이!)"
    ch_player "미안, 중요한 일이라서......"
    ch_turtle "선배선배, 그럼 저랑 인스타 교환하고 가요."
    narrator "(주인공에게 핸드폰을 건넨다.. 인스타그램 앱이 켜진 상태다.)"
    ch_player "뭐 하라는…. 아, 응."
    #휴대전화 자판소리
    #play sound sound_ui_pop
    narrator "(귀연의 휴대전화에 자신의 인스타그램 계정을 검색하고는 다시 핸드폰을 돌려준다.)"
    ch_player "팔로우 하면 맞팔할께...... 요."
    ch_turtle "네엥 선배. 감사합니다!"
    narrator "(기분이 좋은 모양인지 몸을 움칫거린다..)"
    ch_player "(고작 인스타그램 맞팔에 왜 저러지?)"
    ch_player "이름이…. 연이랬나? 연이는 2차 가요?"
    ch_turtle "넹!"
    ch_player "다치지 말고, 집에 잘 들어가고. 재미있게 놀다 가요."

    show scg_yun_glasses_normal at bounce
    ch_turtle "넹. 선배도요!"
    ch_player "응. 그래요. 그리고 말 편하게…. 하자!"

    show scg_yun_glasses_confused
    ch_turtle "어, 그러자…?"
    ch_player "같은 현시연 사람인데 말 그냥 놓아버리자!"
    ch_player " 난 이만 가볼께. 나중에 동방에서 보자! 그때도 지금처럼 말 편하게 해 줘!"
    hide scg_yun_glasses_confused
    show scg_yun_glasses_normal
    ch_turtle "응! 선배 잘 가!"
    hide scg_yun_glasses_normal with dissolve
    narrator "귀연이 주인공을 향해 손을 흔들어준다. 아니, 앞발인가. 아무튼 거북이의 배웅을 받으며, 주인공은 자취방으로 돌아간다."

    $ current_progress += 1
    $ persistent.current_clear = [True, True, True, False, False, False, False, False, False, False]
    $ persistent.current_chapter = 3
    call progress
    scene black with fade
    return

label episode_spring_soodal:

    # 배경 : 기숙사? 
    scene bg_collegebuilding_raining with fade
    play sound sound_rain
    ch_player "(봄이 온다. 이런저런 사건이 많았지만, 무사히 봄이 오고있다. 벚꽃이 피고, 바람은 따뜻해지고, 새싹은 자라나고, 커플들은 연애를 하고... 그렇다 봄은 커플의 계절이다. 지금도 나의 눈 앞에는 데이트를 즐기기 위해 기어나온 커플들이 가득하다. 젠장.. 이 리얼충 놈들... 그냥 비가 와서 싹 다 쓸어가면 좋겠다...)"
    narrator "그리고 그 일이 실제로 일어났다."
    define ch_announcer = Character("아나운서", ctc="ctc_blink", what_slow_cps = 30)
    ch_announcer "현재 영남지방에 폭우가 쏟아지며..."
    ch_player "아니 이게 왜 진짜지.."
    
    show scg_banwoo with dissolve
    ch_banwoo "음? 뭐가?"
    ch_player "ㅇ? 아..아무것도 아냐"
    narrator "(말이 씨가 된다더니.. 정말로 비가 내리기 시작했다. 이정도면 휴교를 때려야 하는거 아닌가... 어.. 그러고 보니 수영이 집이 강변이지 않았나? 이런 폭우면 강이 많이 불어날건데.. 괜찮을려나)"
    ch_banwoo "야야 뭐하고 있냐. 강의 가야지 지각한다."
    ch_player "어어 그래야지 지금 ㄱ..."

    hide scg_banwoo with dissolve
    play sound sound_phone_vibrate
    narrator "우우웅ㅇ!"
    show scg_player_call with moveinbottom
    ch_player "ㅇ..으이? 뭐지"
    narrator "(뭐지.... 전화가 울린다고..? 복학하고 온 전화라고는 중국 국제전화 밖에 없는데..? 일단 받아보자)"
    hide scg_player_call with moveoutbottom
    ch_player "ㅇ..여보세ㅇ.."
    #define ch_soodal = Character("수영이")
    ch_soodal "어 여보세요?"
    narrator "(이 목소리는.. 수영이..? 수영이가 나에게 전화를? 어째서? 무슨 일이지?)"
    ch_player "수..영아.? 무슨 일이야..?"
    ch_soodal "그... 오늘 000교수님 수업 듣지..?"
    ch_player "ㅇ.어어 듣지..?"
    ch_soodal "오늘 강의 좀 녹음 따줄 수 있을까..? 내가 오늘 일이 생겨서 못 갈거 같.."
    play sound sound_earthquake
    ch_soodal "어어..?"
    ch_player "수영아? 괜찮아? 무슨 일이야? 방금 소리 뭐야?"
    ch_soodal "그... 설명하자면 긴데... 일단 잠시만... 그 일단 녹음 좀 부탁할게!!!"

    play sound sound_phone_callexit
    narrator "(뚝)"
    narrator "(이게 무슨 상황인가. 방금 그 소리는 무엇이며 왜 수영이는 이리도 다급하게 전화를 끊는거지? 무슨 일이 생긴건가..? 음.... 안되겠어 가봐야겠다.)"
    ch_player "어이, 칡소."
    show scg_banwoo with dissolve
    ch_banwoo "무슨일이야, 경북대 컴공 베타메일."
    ch_player "오늘 강의, 녹음 좀 부탁하마."
    ch_banwoo "흠, 알겠어 나만 믿어라."
    ch_player "왜인지는 안 묻는 것이야?"
    ch_banwoo "그대와 나 사이에 무슨 질문이 필요한가. 다녀오거라."
    ch_player "그래. 살아서 보자꾸나."
    hide scg_banwoo with dissolve
    narrator "(말이 끝나기 무섭게 나는 달려나갔다. 수업이고 뭐고 지금 중요한 건 그게 아니다. 수영이 집 위치는 대충 알고있으니 근처에서 전화하면 되겠지. 일단, 달리는 것이다.)"
    narrator "(그렇게 우리의 주인공은 오래, 아주 오래 달렸다. 물론 달린 것은 택시라는...)"
    scene bg_sincheonflood with fade
    play sound sound_waterfall
    narrator "(여기 근처가 수영이의 집으로 알고있다. 그런데.... 이 모습은....)"
    ch_player "강이.. 뭐 이렇게 불었..지..?"
    narrator "물이 너무나 많다. 그리고 계속해서 많아진다. 모든 것을 삼킬 듯이 계속해서 쏟아진다."
    narrator "수영이가 걱정이다. 빠르게 전화를.."
    play sound sound_phone_vibrate
    show scg_player_call with moveinbottom
    narrator "(띠리리링...띠리리링...)"
    hide scg_player_call with moveinbottom
    ch_player "..어! 수영아! 너 지금 어디야?"
    ch_soodal "어..? 나 지금 집 앞인데..? 왜 그래..?"
    ch_player "너희 집이 정확히 어디지? 나 지금 근처에 왔거든?"
    ch_soodal "?????..ㅁ..뭐? 왔다고..? 잠시만 너 지금 어디야?"
    ch_player "여기가..(대충 위치 설명)"
    ch_soodal "어.. 잠시만 내가 지금 갈게.."
    narrator "(수영이가 괜찮을까? 목소리에 뭔가 힘이 없다. 아니면 내가 너무 민폐를 끼치는 것일까? 아무런 말도 없었는데 홀로 판단하여 집 앞까지 달려온 내가 민폐는 아닐까...)"
    ch_soodal "[ch_player]!!! 여기야!!"
    narrator "(얼마 떨어지지 않은 곳에서 수영이의 목소리가 들린다. 고개를 돌려 반대 방향을 바라본다.)"
    ch_player "수영아! 괜찮아!? 무슨 일이야??"
    
    window hide
    $ renpy.pause(0.2)
    $ renpy.pause(0.2)
    $ renpy.pause(0.2)
    show cutscene_otter_2 with Pixellate(1, 4)
    $ renpy.pause(100)

    hide cutscene_otter_2 with Pixellate(1, 4)
    $ renpy.pause(0.2)

    show scg_suyeong_worried with dissolve
    ch_soodal "그... 설명하자면 긴데..."
    ch_player "일단.. 어디 들어갈 수 있을까? 너희 집이라던가..."
    narrator "(아니 생각해보니 이상하잖아 다짜고짜 집에 들어간다니 이게 맞나..?)"
    ch_soodal "그게.. 사실 이 아래가 우리 집이야..."
    ch_player "ㅁ..뭐????"
    narrator "그렇다, 수영이의 집은 강둑에 있었다. 과도하게 내린 비로 인해 강둑이 수용할 수 있는 수위를 넘어서버려, 지금 이렇게 집이 수장된 것이다. 지구온난화가 이렇게 위험한 것이구나.."
    ch_player "그러면 너 집은 어떻게 해...?"
    ch_soodal "아마 이사 가야겠지... 주변 어디든..."
    ch_player "그러면 그동안 잘 곳은...?"
    ch_soodal "어...과방이나...음...잘 모르겠네..."
    ch_player "ㄱ..그러면 ㅇ..우리집은 어때?"
    narrator "(아니나뭐라는거야 갑자기남자집에서자라고하다니 미쳤나봐이거범죄아니야? 이제어떻게해야ㅎ..)"
    ch_soodal "ㅈ..정말 그래도 될까..?"
    ch_player "!?!?!?!!"
    narrator "(아니 이걸 승낙한다고..?)"
    ch_player "ㄷ...당ㅇ윤하지..!"
    hide scg_suyeong_worried with dissolve
    narrator "(그렇게 달수영은 내 자취방에서 생활하게 되었다...라는 이야기라면 좋았겠지만.."

    #무슨 컷신?
    narrator "그 빗길을 달려온 나는 수영이와 대화 직후 저체온증으로 쓰러지게 되었고, 바로 입원하며 수영이는 그런 나를 옆에서 간호하며 자취방을 알아보았다. 그리고 정말 다행히도 야생동물보호협회에서 수영이의 자취방(강둑)을 다시 얻어주어서 그곳으로 돌아가게 되었다. 메데타시~ 메데타시~~......)"
    ch_player "(젠장... 내 인생의 러브코미디는 왜 항상 코미디만 남을까.....)"
    ch_player "(오늘따라 반우가 보고싶구나...)"

    $ current_progress += 1
    $ persistent.current_clear = [True, True, True, True, False, False, False, False, False, False]
    $ persistent.current_chapter = 4
    call progress
    scene black with fade
    return

label episode_spring_heron:

    # 강의실실
    scene bg_lecture_room with fade
    show scg_heesul_normal with dissolve
    ch_heron "···이러한 자료에 근거해 저희 조는 현대 사회에서도 결혼이 꼭 필요한 제도라고 생각합니다."
    #show scg_gal at center
    
    narrator "짝짝짝짝"
    narrator "발표 이후 희설 씨와의 관계가 더욱 친밀해진 것 같은 기분이 든다."
    narrator "물론 락 사건의 비중이 크겠지만···."
    ch_heron "그래서 나는 이 노래가 좋아! 너는 어떤 것 같아?"
    narrator "시시때때로 락에 대한 이야기만 나오면 돌변하는 태도."
    ch_player "(과연 이 사람이 내가 알던 쿨한 갈희설 씨가 맞나?)"
    ch_player "(이러한 의문까지도 들기 시작했다···.)"

    ch_prof "의사소통. 이것이 인간 간의 관계의 핵심입니다."
    ch_prof "말 한마디로 천냥 빚을 갚는다. 이러한 속담이 있을 정도로 의사소통의 중요성은 과거로부터 크게 강조 되어 왔습니다."
    ch_prof "그리고 인간 관계의 정수라면 바로 연애이겠죠."
    ch_prof "서로가 서로를 위하는 깊은 관계라니! 얼마나 아름답습니까!!!"
    ch_prof "마침 딱 벚꽃 시즌이기도 하니, 다음 시간에는 센트럴 파크에서 피크닉, 하겠습니다."
    ch_prof "돗자리와 가벼운 요깃거리를 챙겨서 it 1호관 앞 주차장으로 모이기로 하죠."
    ch_prof "뒷정리 잊지 말아야 합니다!!!"
    ch_player "교수님이 괴짜라더니 이런 좋은 점도 있네요."
    ch_heron "그러게 말이야."
    hide scg_heesul_normal with dissolve
    scene bg_black with fade
    narrator "그렇게 며칠의 시간이 지난 후···."
    
    #장소 : 센트럴 파크
    scene bg_picnic with fade
    ch_player "드디어 소풍날이네요."
    
    show scg_heesul_normal with dissolve
    ch_heron "응. 기대되네."
    ch_player "오늘 간식거리로 뭐 챙겨오셨어요?"
    
    hide scg_heesul_normal
    show scg_heesul_smile
    ch_heron "후훗. 비밀인데?"
    ch_player "(왠지 모를 오한이 몸에 드는 것만 같다···.)"
    #scene bg_cherryblossom_park
    ch_player "여기가 딱 평평한게 좋네요."
    ch_heron "그렇네. 그럼 여기로 하자."
    narrator "돗자리가 펴지고, 여러가지 포장 용기들이 돗자리 위에 올라왔다."

    # 반짝 스프라이트와 상하움직임 연출은 transform, animation, add 사용
    #show sparkle on scg_gal
    ch_heron "우후훗."

    ch_player "희설 씨. 저 몰래 이상한 행동 하고 다니는 거 아니죠?"
    ch_heron "으흐흐. 뭘 걱정하고 있어."
    ch_player "으으음···."
    ch_player "근데 저 검은색 통은 뭐에요?"
    #show black_box at right
    hide scg_heesul_smile
    show scg_heesul_normal
    ch_heron "비밀이야."
    ch_heron "근데 이상한건 아니야. 평소에 내가 늘 만들어 먹는거거든."
    ch_heron "몸에도 좋은거니 기대해도 좋아."
    ch_player "···넵."
    #play sound "wind.ogg"
    #narrator "···(휘이잉~ 하는 바람 소리를 삽입한다.)"
    ch_heron "[ch_player], 왜이리 굳어있어."
    ch_heron "피크닉 처음이니?"
    ch_player "···넵."
    ch_heron "일단 음식 포장부터 열자."
    narrator "다양한 음식들이 돗자리 위에 모습을 드러냈다."
    ch_player "떡볶이, 샐러드··· 이거 다 직접 하신거에요?"
    ch_heron "후훗. 자취하다보니 요리 실력 좀 키웠지."
    ch_player "와! 먹어봐도 돼요?"
    ch_heron "먹고 감동받아서 울면 안된다?"
    ch_player "설마 그러겠어요?"

    #scene black
    ch_player "—훌쩍."
    ch_heron "야··· 야! 진짜 울면 어떡해! 괜찮아?"
    ch_player "어릴적 해맑게 뛰놀던 시절이 기억나 저도 모르게 눈물이··."
    ch_heron "오버하지말고. 자 여기 손수건. 눈물 좀 닦아봐."
    ch_heron "아니 잠깐. 지금이 좋겠다."
    
    
    ch_heron "[ch_player], 잠깐 눈 좀 감아봐."
    ch_player "네? 뭔 짓을 하시려고···."
    ch_heron "잔말 말고 얼른 감아봐."
    ch_player "넵."
    show black with dissolve
    ch_heron "아~"
    narrator "입 안에 무언가 들어오는 것이 느껴진다."
    play sound sound_chewing_cookie
    ch_player "(뭔가 딱딱한데···. 쿠키인가?)"
    narrator "오독오독."

    hide black with fade

    show scg_heesul_normal with dissolve
    ch_heron "자. 어땠어?"
    ch_player "쿠키 같았는데···. 고소하고 맛있었어요."
    hide scg_heesul_normal
    show scg_heesul_smile
    ch_heron "그렇지? 너도 맛있다고 생각하지?"
    ch_player "정체가 뭐길래 그래요?"
    ch_heron "놀라지 말고."
    narrator "검은 통의 뚜껑이 열리고 안의 내용물이 보인다."


    #play sound "dramatic.ogg"
    # 밀웜 쿠키 일러스트 삽입하면 좋음
    #show mealworm_cookies at center



    narrator "가득 보이는건 역동적인 포즈를 취한 갈색의 원통형 물체들."
    ch_player "···벌레?"
    ch_heron "아니 벌레라고 하는건 실례야. 그런 잡스런 곤충과 다른 ***밀웜***이라고."
    ch_player "저는 번데기도 징그러워서 못 먹는데···."
    ch_heron "아니 들어봐 밀웜이 얼마나 몸에 좋은데. 단백질 함량이 소고기보다 더···."
    show bg_black at transparent_50 with dissolve
    narrator "점점 속이 메스꺼워져온다. 대체 갈희설 씨는 내게 뭘 먹인건가."
    
    ch_player "욱."
    hide scg_heesul_smile with dissolve
    
    narrator "미니게임이 시작됩니다."
    narrator "구토를 힘껏 참으세요, 게이지를 40\% ~ 60\% 사이로 버티면 성공입니다."

    show bg_black at transparent_75 with dissolve  
    call gauge_minigame_label
    if gauge_result:
        "성공"
    else:
        "실패"
    hide screen gauge_minigame with dissolve

    scene bg_picnic with fade

    show scg_heesul_normal with dissolve
    ch_heron "괜찮아?"
    ch_player "우웨엑."
    narrator "화장실가서 잔뜩 토했다···."


    $ current_progress += 1
    $ persistent.current_clear = [True, True, True, True, True, False, False, False, False, False]
    $ persistent.current_chapter = 5
    call progress
    scene black with fade
    return

label episode_spring_turtle:

    # 장소 : 현시연 동방
    scene bg_club_room with fade
    ch_player "현시연 동아리 방."
    narrator "각자 자신의 일에 몰입하고 있는 부원들이 있다."
    narrator "평소와 같은 풍경 -"
    ch_player "나도 그 풍경의 일부로서, 거기 껴서 할 일을 하는 중이다."
    ch_player "오늘까지 제출인 과제가 있긴 하지만, 나는 그런 것 따위는 신경쓰지 않는다."
    ch_player "아주 한심하게 보일 정도로, 중요한 일이니까."
    ch_player "그런 과제같은 하찮은 것을 할 시간에, "
    
    ch_player "부원들하고 애니메이션 '나는 내일의 아침밥이지만 당신은 오늘의 저녁밥입니다만? ~끼니를 챙겨먹는 것은 아주 중요해~'의 주인공의 정실은 G인지, K인지에 대해서 고급진 토론을 하는 것이 더 가치있으니까."
    
    show scg_yun_glasses_confused with dissolve
    ch_turtle "서, 선배. 나 하고 싶은 말이 있는데........!"
    ch_player "(헉, 무슨 일이지?)"
    ch_player "어, 으응. 뭐?"
 
    # 채팅창 흔들림 효과
    #show screen shake onlayer master
    hide scg_yun_glasses_confused
    show scg_yun_glasses_shouting
    ch_turtle "나...... 나!"
    ch_turtle "선배 안녕? 나 선배랑 밥이 먹고 싶은데 혹시 괜찮을까?"

    ch_turtle "{cps=100}오늘저녁도괜찮고목요일저녁도괜찮고나금요일에교수님이휴학을한다고해서 아니휴학이아니고자퇴인가? 아니자퇴는아닌데"
    
    show bg_club_room with hpunch
    ch_turtle "{cps=100}으아앙이런말하고싶던게아니였는데~!!!!!! 아무튼교수님이금요일에수업이없다고그래서수업이없거든 그래서공강이라금요일도괜찮아!! 언제든지괜찮아!! 점심시간도다괜찮아!!"

    #hide screen shake
    
    
    ch_player "지금 나한테 바...... 밥사달라는 소리야?"
    ch_player "(뭔 거북이가 말을 이렇게 빠르게 해?)"
    hide scg_yun_glasses_shouting
    show scg_yun_glasses_surprised
    ch_turtle "네에.....!"
    ch_player "그, 그래! 까짓거 밥 한 번 먹자. 내일 점심 어때?"
    ch_player "(매뉴는.......)"
    ch_player "(큰일났다! 나 찐따라서 아는 밥집이 없는데....... 아! 그래 공대에 명물 하나 있지!)"
    ch_player "학식! 그래. 베이직하게 학식 먹자. 공식당 아직 안 먹어봤지?"
    ch_player "(여자 후배랑 밥약인데 고작 학식이라니! 쪼잔하다고 생각하지는 않겠지?)"
    ch_turtle "네엥, 선배애...... 내애일 점시임시가안에 고옹시익다앙으로오 갈께요오......"
    hide scg_yun_glasses_surprised with dissolve
    ch_player "그래! 그럼 내일 보자." 
    ch_player "(...... 말 멀쩡하게 하다가 갑자기 왜 저래?)"


    # 강의실
    

    scene bg_zidomot with fade
    narrator "귀연과 주인공, 함께 공대 학생식당으로 이동한다."

    ch_player "뭐 먹고 싶은 거 있어?"
    show scg_yun_glasses_normal with dissolve
    ch_turtle "이거 어때요옹?"
    narrator "(에브리타임 학식 탭을 키고는 “산더미 오리주물럭” 을 보여준다.)"
    # '산더미 오리주물럭' 사진 보여주기, 이미지 삽입 가능
    ch_player "이거 둘이 먹는 거 아니야?"
    ch_turtle "네엥. 무슨 문제라도 있어요? 선배 혹시 오리 알레르기 있어요?"
    ch_player "(그러네......! 나 혼자가 아니니까 이제 이거 먹을 수 있네. 연이가 있으니까! 혼자가 아니야! 그러니까...... 2인 매뉴를 시킬 수 있어!)"
    ch_player "아니, 좋아! 이거 먹자!"

    ch_turtle "아, 잠시만요…… 선배, 저 가방 좀……"
    ch_player "(귀연의 가방을 들어준다.) 어? 왜?"

    hide scg_yun_glasses_normal with dissolve
    ch_turtle "(안경을 벗고 케이스에 넣는다.)"

    show scg_yun_normal with dissolve
    ch_turtle "밥 먹을 땐… 안경에 김 서려서요…… 불편해서……"
    
    # 주인공 내부 독백
    ch_player "잠깐만. 지금 뭐야. 뭐라고? 안경을…… 벗는다? 야 이거… 이거 이거 이거…"
    
    ch_turtle "(고개를 살짝 갸웃) 선배? 괜찮으세요? 왜 얼굴이 빨개지셨어요……?"
    
    ch_player "머리에서 재난문자 울려퍼져앗!"
    ch_player "귀여움 농도 초과! 경고! 경고!!"
    ch_player "아니 진짜 미쳤다. 원래 귀여운 건 알고 있었는데, 안경 벗었다고 사람이 이렇게 달라져?"
    ch_player "이거 무슨 안경형 마법소녀였냐고!!"
    
    ch_player "아, 아니야… 아무것도…!"
    
    ch_turtle "그럼, 제가 버너 챙기고 자리 잡고 있을게요오~ 선배는 주물럭 받아오세요!"
    
    narrator "오리주물럭은 금방 나왔다."
    narrator "주인공은 오리주물럭을 들고 귀연에게로 갔다."
    
    ch_player "헉, 많이 기다렸지?"
    ch_player "(트레이를 내려놓으며) 이야, 진짜 양 많네."
    
    ch_turtle "(은근슬쩍 웃는다) 그쵸오~? 이거… 에타에서 보고 꼭 이거 먹어보고 싶었어요!"
    
    ch_player "(안경 벗은 거, 진짜 귀엽네)"
    
    ch_turtle "선배, 왜 저 그런 눈으로 봐요?" 
    ch_turtle "불 좀 켜주세요오~ 저 아직 이거 켜는 거 잘 몰라서……"
    
    ch_player "어, 내가 할게."
    ch_player "(떨리는 손으로 가스버너를 킨다.)"
    
    ch_turtle "헤헷, 감사합니다아"
    
    ch_player "(이거 진짜 현실 맞나? 이렇게 초절정으로 귀여운 후배랑 밥약이라니, 내 대학생활 드디어 시작인가?)"
    
    narrator "지글지글 고기 끓는 소리가 난다."
    
    ch_turtle "선배…… 이제 거의 다 익은 것 같아요~ 먼저 드셔보세요~"
    
    ch_player "(한 점 집어 먹는다)"
    ch_player "(음. 따뜻하고 맛있다. 정말로 사람이랑 같이 밥 먹는 기분…….)"
    ch_player "(살짝 멍하니 귀연을 본다)"
    
    ch_turtle "선배? 왜 또 그런 눈으로? 맛없어요?"
    
    ch_player "아, 아냐! 완전 맛있어! 진짜! 고기보다 네 얼굴… 아뇨, 그게 아니라, 하여튼 맛있다!!"
    
    ch_turtle "(킥킥 웃는다) 다행이에요오~"
    
    narrator "도란도란 수다를 떨며 오리주물럭을 먹는 둘. 어느새 식사를 마친다."
    narrator "둘은 함께 오리주물럭 그릇을 반납한 다음 밖으로 나간다."
    
    ch_player "(와, 무슨 말을 했는지도 기억 안 나는데…… 좋았다. 그냥……)"
    
    ch_turtle "오늘,,,~ 같이 먹어주셔서 감사했어요~ 선배. 저, 재밌었어요!"
    
    ch_player "나도. 나도 진짜 재밌었어."
    
    ch_turtle "그럼, 다음엔 커피 한 잔 해요오~ (작게 손 흔들며) 동방에서 봐요~ 선배애~"
    
    hide scg_yun_normal with dissolve
    ch_player "(…… 나, 지금……. 카와이 후배짱이랑 밥약하고 커피 약속 잡았어.)"
    ch_player "(아냐, 이거는 진짜…… 꿈이라도 좋아. 그냥 깨어나지 말자…….)"


    $ current_progress += 1
    $ persistent.current_clear = [True, True, True, True, True, True, False, False, False, False]
    $ persistent.current_chapter = 6
    call progress
    scene black with fade
    return

label episode_midterm_turtle:
    # 장소 : 술집
    narrator "어느 날과 같은 동아리 모임이 끝나고 현시연 부원들은 뒷풀이를 위해 ‘끝소’ 로 이동했다."
    narrator "자연스럽게 귀연과 주인공은 같은 테이블에 앉는다."
    show scg_yun_normal with dissolve
    ch_turtle "선배앵~"
    narrator "(특유의 늘어지는 말투로 주인공에게 반갑게 인사를 한다.)"
    ch_player "어. 연이 하이~"
    ch_turtle "선배 오늘은 끝까지 있어?"
    ch_player "오늘은 완전 오케이지. 일단 먹자. 주문부터 고고."
    narrator "주문을 마치자 곧 주문했던 음식들과 술이 나온다."
    narrator "뒷풀이에 온 부원들이 즐겁게 담소를 나눈다."
    define ch_staff = Character("현시연 임원",ctc="ctc_blink", what_slow_cps = 30)
    ch_staff "자, 집 갈 사람은 가고 2차 갈 사람은 갑시다!"
    narrator "귀연과 주인공, 함께 2차 장소로 이동한다."
    hide scg_yun_normal with dissolve
    # 2차 술집

    # scg 변경
    narrator "처음부터 거하게 달린 것인지 귀연의 얼굴이 벌써 불그스름하다."
    ch_player "(저러다 가겠는데. 신경써야겠다.)"
    narrator "(귀연의 머리카락을 보고는 흠칫한다.)"
    ch_player "연아. 너 머리카락에 뭐가 붙었어."
    ch_turtle "지, 진짜요? 빨리 때야겠다."
    narrator "(앞발을 머리에 올리고 흐느적거리지만, 취해서 그런지 머리에 붙은 밥풀을 쉽사리 잡지 못한다.)"
    ch_player "아니, 거기 말고. 그 윗쪽에...... 가만있어 봐. 내가 때는 게 빠르겠다."
    narrator "(귀연의 머리카락에 손을 올린다. 자, 여기...... 되었다. 머리카락에 붙은 밥풀을 때는 과정에서, 귀연의 머리카락이 넘어가면서 귀가 들어난다.)"
    ch_player "근데 너 귀가 왜이리 빨갛냐? (벌써 취했나? 오늘 좀 빠르게 마시긴 했지만, 아직 이 정도는 아닌 것 같은데.)"
    ch_turtle "(갑자기 표정이 사색이 된다.) 서, 선배애. 설마 본 거 아니.......?"
    ch_player "귀? 왜? 좀 빨갛긴......"
    ch_turtle "선배애그걸보시면어떻게해요!!!!"
    narrator "(갑자기 와다다다 말을 내뱉기 시작한다!)"
    ch_turtle "그거를보시면어떻게해요 학교이제어떻게다녀 으아아아아아아아아앙ㅠㅜ 당장휴학해야겠다 아니그냥자퇴를해야겠다 학교를옮겨서새시작을해야겠어 수능다시쳐야하나? 그건 싫은데....... 하지만 귀가 보였는데 이 학교를 다닐 순 없어....... 메가스터디회원가입다시해야겠다 아니작년에쓴계정있으니까비밀번호찾기를해야하니? ㅠㅜ...... 아무튼나이제학교못다녀"
    ch_player "아니, 뭔 갑자기 자퇴를......"
    ch_turtle "선배나를이제그만잊어주세요 선배와함께있을수있어즐거웠어요 근데귀가보인이상나는더이상선배랑있을수없어요ㅠㅜ"
    ch_player "무슨 소리야, 귀가 뭐 어때서."
    ch_turtle "너무 흉물스러운데......."
    ch_player "아니, 하나도 안 그래. 오히려 귀여운데."
    ch_player "(괜한 말을 한 건 아니겠지?)"
    ch_turtle "내 귀 진짜 귀여워요오~?"
    ch_player "어, 으응!"
    ch_player "(기분이 좀 풀린건가? 다행이다!)"
    ch_turtle "(안도했는지 미소를 짓는다. 평소와 같은 여유넘치면서도 나른한 얼굴이다.) 다....... 행........ 이........ 다....... 아........"
    ch_player "(갑자기 말이 급격히 느려졌어! 아까 말 따박따박 하던 애 맞아?)"
    ch_turtle "내에에에에귀이이지이이이이인쯔아아아아아아아아안이이이이이이사아아아아안거어어어어어어죠오오오오오?"
    ch_player "(지금 내 귀 진짜 안 이상하다고 물어보는 건가?)"
    ch_player "어! 하나도 안 이상해. 오히려 귀엽다니까?"
    ch_player "(하이씨, 여자한테 자꾸 귀엽다고 하니까 부끄럽네)"
    ch_turtle "나아아아아아아안노오오오오오올리이이이이이일꺼어어어어어어어에에에에에요오오오오오오?"
    ch_player "'나.... 안.... 놀..... 릴..... 꺼..... 에..... 요?'"
    ch_player "당연하지! 그걸 왜 놀려? 내가 뭔 초등학생도 아니고! 그리고 귀...... 귀엽다니까! 귀여운 걸 왜 놀려!"
    ch_player "(육성으로 자꾸 귀엽다 귀엽다 하니까 나까지 미칠 것 같네! 근데 뭐, 틀린 말도 아니니까!)"
    ch_turtle "선배애...... 거짓말 아니죠오?"
    ch_player "진짜야! 내가 왜 이렇게까지 거짓말을 해! 내가 지금 너한테 구라까는거면......"
    narrator "(귀연에게 핸드폰을 보여준다. 핸드폰 화면에는 애니메이션 나는 『 내일이 아침밥이지만 당신은 오늘의 저녁밥입니다만? ~끼니를 챙겨먹는 것은 아주 중요해~ 』 의 등장인믈 G의 피규어 구매내역서가 있었다.)"
    ch_player "이거 받자마자 너 준다! 물량을 쥐꼬리만큼 풀어서 지금 중고나라 가 보면 플미 장난 아니야. 지금 구라까는거면 진짜 너 줄테니까 받아서 되팔던지 부시던지 네 마음대로 해!"
    ch_turtle "정말 진심으로 내 귀가 귀엽다고 생각하는 거에요?"
    ch_player "(다행이다. 진정했어!)"
    ch_player "그래! 그러니까 너무 그러지 마. 네 귀, 너만의 매력 포인트라고!"
    ch_player "(으아아. 나 지금 느끼한 말을 너무 많이 하고 있어!)"
    ch_turtle "(눈이 살짝 그렁그렁해진다.) 나 진짜 감동이에요......."
    narrator "(갑자기 길바닥에 털썩 주저앉는다.)"
    ch_player "괜찮아?"
    ch_turtle "갑자기 다리에 힘이 풀렸어요오...... 컨디션이 갑자기 이래서 오늘 2차까지 가는 건 어려울 것 같네요. 먼저 들어가볼께용. 선배 재미있게 놀다 와요,,,~"
    ch_player "대려다 줄께!"
    ch_turtle "아니에요! 일청담 요 근처니까 나 혼자서도 갈 수 있어요!"
    ch_player "아니야. 너 지금 상태 완전 맛이 가서...... 대려다 줘야 내 마음이 편하겠어!"
    ch_turtle "서, 선배애......."
    narrator "(귀연, 갑자기 앞발로 얼굴을 감싼다.)"
    ch_turtle "그러면 같이가요오......"
    ch_player "(갑자기 얼굴은 왜 가리지?) (굳이 묻지는 말아야겠다. 또 갑자기 그러면 힘드니까......)"
    narrator "주인공과 귀연. 함께 한 밤 중의 캔퍼스를 같이 걷는다."
    narrator "한밤중의 고요한 캔버스. 바람이 가로수에 스치는 소리 말고는 아무 소리가 들리지 않는다."
    narrator "술을 마셔서 그런지 알딸딸하다. 아니, 옆에 귀연이 있어서 그런가. 꿈을 꾸는 듯한 기분. 편안하고 좋다."
    narrator "느즈막히 걷다 보니, 어느새 일청담이 나왔다."
    ch_turtle "저 이제 들어가볼께요."
    narrator "퐁당 거리는 소리와 함께 귀연이 사라졌다."
    ch_player "(잘 들어갔겠지?)"
    narrator "그럴 거라고 믿으며, 주인공은 홀로 자취방으로 걸어갔다."

    return

label episode_midterm_heron:

    #검은 배경
    scene black
    narrator "지난 번의 밀웜 쿠키 사건 이후."

    # 회상: 벚꽃 배경에 노란색 필터
    scene bg_cherryblossom with fade
    show yellow_filter
    ch_heron "너··· 진짜 괜찮은거 맞아···?"
    ch_heron "얼굴이 핼쑥한데···."
    ch_player "진짜 괜찮아요···."
    scene bg_library_lobby with fade

    narrator "이렇듯 갈희설과의 관계는 지난 번 이후 꽤나 소원해진 상태다."

    ch_heron "···."
    ch_player "·····."
    ch_player "저··· 희설 씨? 괜찮으세요?"
    ch_heron "너야 말로 괜찮아? 좀 더 조심했어야 하는데···."
    ch_player "(너무 분위기가 가라앉는 것 같은데···.)"
    ch_player "(뭐라도 해서 이 어색함을 깨야한다!)"
    ch_player "희설 씨. 일단 공부부터 할까요?"
    ch_heron "으음···? 으응."

    scene bg_studyroom with fade
    play sound "bag_down.ogg"
    ch_player "이왕 스터디룸 예약한 김에, 겹치는 결혼과 가정 공부 같이 하는거 어때요?"
    ch_heron "···그럼 좋지."
    ch_player "희설 씨, 이 문장 어떻게 생각해요?"
    ch_heron "음···. 친밀하다고 해서 상대의 마음까지 다 알 것이라고 착각하지말라는 뜻 아닐까?"
    ch_heron "대부분의 불화도 다 소통, 대화의 부재로 일어난다잖아."
    ch_player "그렇죠. 아무리 오래 알고 지낸 사이라도 상대방 마음 깊은 곳까지 속속들이 알기는 힘드니까요···."
    ch_heron "그렇지. 다 대화를 하고 살아야한다니까!"
    narrator "그렇게 대화가 이어지고···."
    play sound "ding.ogg"
    narrator "퇴실 10분 전 입니다."
    ch_player "시간이 엄청 빠르게 지났네요."
    ch_heron "그렇네."
    narrator "시계를 보니 7시. 벌써 해가 뉘엿뉘엿 넘어가는 시간대가 되어 있었다."
    ch_player "그럼 다음에 다시 보도록 하고. 오늘은 이만 해산할까요?"
    ch_heron "응, 그래."

    # 비 오는 사진 배경
    scene bg_rainy_building with fade
    play sound "rain.ogg"
    ch_player "아···."
    ch_heron "망했네."
    narrator "밖으로 나와보니 세찬 빗줄기가 내리고 있었다···."
    ch_player "일기 예보에는 이런 말 없었는데···."
    ch_heron "일기 예보 틀리는게 하루 이틀도 아니고."
    ch_heron "[ch_player], 우산은 들고 왔어?"
    ch_player "아니요···."
    ch_heron "어휴 칠칠맞기는. 나는 우산들고 왔으니까 같이쓰고 가자."
    ch_player "네."
    ch_player "네···?"
    ch_player "저희 가는 방향이 다르지 않나요?"
    ch_heron "그럼 누구 하나 비 맞고 가게?"
    ch_heron "그냥 우리집 와서 우산 하나 빌려가."
    ch_player "정말 그래도 되나요?"
    ch_heron "당연하지. 부담가지지말고 따라와."
    narrator "···."
    ch_player "(저 누나는 경계심도 없나···.)"
    ch_player "(아무리 친한 나라해도 외간 남자인데···.)"

    scene black
    narrator "이런저런 잡생각을 하다보니 어느새 희설 씨의 집에 도착했다."
    scene bg_one_room_floor with fade
    ch_heron "여기가 내 집이야. 자취방에 초대하는 사람은 너가 처음이니까 영광으로 알아."
    ch_heron "이상한 생각은 하지말고."
    narrator "다른 사람, 특히 이성의 집을 가보는 것은 처음이기에 특히 긴장이 된다."
    scene bg_one_room_corridor with fade
    ch_heron "눈 감아."
    scene black
    play sound "password.ogg"
    play sound "door_open.ogg"
    scene bg_one_room_corridor with fade
    ch_heron "여기가 내 집이야."
    ch_player "실례하겠습니다."
    scene bg_one_room_in with fade
    pause 2
    ch_player "···."
    ch_heron "어때, 여자집 처음 와본 기분은?"
    ch_player "정갈하네요. 물건들이 난잡하게 있지도 않고."
    ch_heron "어? 어. 고마워···."
    ch_heron "집에 손님을 초대한 입장으로서 아무 것도 없이 보내는 것도 좀 그렇지."
    ch_heron "뭐 좀 먹을래?"
    ch_heron "가령 라면이라던가?"
    ch_player "!"
    narrator "이런 장르에서 빠질 수 없는 그 한마디 “라면 먹고 갈래?”"
    ch_player "(나도 살면서 이런 일을 다 겪어보는구나.)"
    narrator "가슴 한구석이 벅차오른다!"
    ch_player "네↗!"
    ch_heron "방금 말하다가 삑사리 난거야? 쿡쿡. 재밌네."
    ch_player "···."
    ch_heron "아 맞다."
    ch_heron "방금 찾아봤는데 집에 라면 밖에 안 보이네···."
    ch_heron "말은 그렇게 했지만 손님한테 라면 대접은 좀···."
    ch_player "아, 아녜요. 저 라면 좋아해요."
    ch_heron "그래? 그러면 최대한 맛있게 끓여보도록 할게."
    ch_heron "내가 늘 끓여먹는 방식으로 말이지."
    narrator "희설 씨의 방식···."
    narrator "밀웜의 악몽이 되살아나려한다···."
    ch_player "(설마 또 괴식이 나오겠어? 설마···.)"
    narrator "그렇게 얼마간의 시간이 지나고···."
    ch_heron "오래 기다리셨습니다~."
    narrator "드디어 만나게 된 라면의 정체."
    ch_player "···한강라면?"
    narrator "깊은 한강의 수심을 표현한걸까? 라면의 물은 많다라는 표현을 넘어 넘치기 직전이었다."
    ch_player "저기 희설 씨···."
    ch_heron "응?"
    ch_player "혹시 평소에도 라면 끓일 때 이렇게 드시나요?"
    ch_heron "···. 맛만 좋구만."
    narrator "토라진 표정이 귀여워 보인다."
    ch_player "(응? 귀엽다고?)"
    ch_player "(나도 드디어 눈에 콩깍지가 씌인건가···.)"
    narrator "끼엑—"
    narrator "그 순간 귀에 기묘한 소리가 들려왔다."
    ch_player "희설 씨 괜찮으세요? 안색이 안 좋아보이는데."
    ch_heron "····."
    ch_heron "***끼에에에에에에엑!!!***"

    scene black
    scene bg_karaoke with fade
    ch_player "···그래서 비 오는 날 마다 본능적으로 소리를 지르게 된다고요?"
    ch_heron "응···. 나도 노력해봤는데 고치진 못했어."
    ch_heron "집에 손님 초대하고 못볼꼴을 보였네···. 미안해."
    ch_player "아니요 이해해요."
    ch_player "근데 그러면 평소에는 소리를 지르고 싶다거나 그러면 어떻게 해소하나요?"
    ch_heron "학교 뒷산에 가서 소리를 지른다거나? 했어."
    ch_player "(뒷산의 귀신이 희설 씨였구나···.)"
    ch_player "그렇다면 노래방 같은 곳은 따로 안 다녀보셨나요?"
    ch_heron "···가봤어야 알지."
    ch_player "희설 씨라면 되게 친구도 많고 잘 놀러다닐거 같은 이미지였는데."
    ch_heron "놀리는거니?"
    ch_player "하하 아니요."
    ch_player "일단 노래부터 부르시죠. 제가 같이 있어드릴게요."
    narrator "이후 갈희설의 3시간 샤우팅을 듣게된 나는 며칠이 지나도록 귀에서 이명이 울리게 되었다···."

    return

label episode_MT_soodal:

    narrator "복학생에게 가장 힘든 시련이 무엇일까. 복학을 한 첫 날? 갑작스러운 후배와의 밥약? 아니면... 얼떨결에 가게 된 MT? 그리고 그 속에서 벌어지는 술게임?"
    narrator "일단 확실한 건, 난 이 모든 것을 겪고있다는 것이다."
    define ch_enemy = Character("과 원수들", ctc="ctc_blink", what_slow_cps = 30)
    ch_enemy "[player_name]가~ 좋아하는~ 랜덤 게임~! 게임~ 스타트!"
    ch_player "(난 왜 이러고 있을까. 복학생이 어째서 새내기들이랑 술게임을 조지고 있지? 어디서부터 잘못된 것일까....)"
    define ch_newbie = Character("새내기")
    ch_newbie "어? 선배 왜 가만히 있어요? 병신샷! 병신샷!"
    ch_player "ㅇ..어.? 어어어?"
    ch_player "(젠장... 어디서부터 잘못되었긴.... 다 나의 탓이지....)"
    narrator "한 달 전, 엠티 신청을 받던 날, 난 당연히도 가지 않으려 했다. 하지만, 그때 갑자기 전화기가 울렸고, 전화를 받자 그곳에서는 수달 한 마리의 목소리가 흘러나왔다."
    narrator "갑작스러운 그녀의 전화에 난 약 3492번째 아들 이름을 생각하기 시작했지만, 그런 망상도 잠시 그녀는 나에게 엠티를 좀 도와달라고 부탁을 해왔다."
    narrator "과학생회 사람 한 명이 코로나에 걸렸다나 뭐라나... 당연히 스윗가이인 나는 (쫄아서) 거절 할 수 없었고 이렇게 복학생의 신분으로 엠티를 오게 되었다."
    ch_player "(아... 다음에는 거절하는 법을 좀 배우자... 무서워도 살아야지...)"
    narrator "그렇게 미친듯이 병신샷을 마시며 점점 정신을 잃어갈 때, 누군가 말을 걸었다."
    ch_soodal "[player_name]아 괜찮아?"
    ch_player "ㅇ..ㅇ으익? 으엉 거ㅐ치ㅏㄴ하"
    ch_soodal "안 괜찮은거 같은데... 우리 좀 나갈까?"
    ch_player "ㅇ..어아 그러ㅜㅀㅎ자"
    ch_soodal "얘들아~ 나 잠시만 이 선배 좀 빌려갈게~~"
    ch_enemy "오~~ 둘이 머야머야~~ 오~~~"
    narrator "주변에서 뭐라고 하는 소리가 들리는 것 같지만 모르겠다. 지금은 너무 정신이 없다. 뭔가 비늘을 잘 잡을 것 같은 감촉의 손만 느껴진다.. 수생생물의 비린내와.. 수영이의 목소리....?"
    ch_soodal "듣고있어? 좀 괜찮니?"
    ch_player "수...수영아? 어어어 듣고있지"
    ch_soodal "뭔가 미안하네.. 도와달라고 했던 건 나인대,,,, 너무 고생만 시키고 있아..."
    ch_player "ㅇ..아니야 꽤나 재미써..."
    ch_soodal "그래두... 아까도 술 게임에서 혼자 엄청 마시고 있었고..."
    ch_player "ㄱ.ㅡ..그건 내가 너무 못해서 그런거라구.."
    ch_soodal "그래도... 음,... 일단 우리 어디 앉을까? 어! 저기 괜찮아 보인다."
    ch_player "ㅇ..으응 그래"

    narrator "나와 수영이는 길가의 작은 벤치에 나란히 앉는다. 밤의 선선한 바람이 불어오고, 달빛은 적당히 내리쬐어 아늑하고도 다정한 느낌이 난다."
    narrator "수영이는 자연스럽게 가방에서 생선을 꺼낸다. 저게 왜 들어있고, 어떻게 보관하는지는 모르겠지만 그냥 생각하기를 포기했다."
    ch_soodal "있자나.. 나 진짜 너에게 항상 고마워.."
    ch_player "ㅇ,,응? ㄱ..갑자기..?"
    ch_soodal "저번에 집 무너졌을 때도 그렇구... 카페 일도 있구... 이번에도 도와줬고.. 진짜 너무 고마운거 있지..."
    ch_player "ㅇ..아아냐 그냥 뭐,... 내가 하고싶으니까 한거지...."
    ch_soodal "진짜.. 너 너무 착한거 아니냐구.."
    ch_player "ㅇ..아니야.. 뭘.,.."

    ch_player "(뭔가뭔가..... 뭔가뭔가 말이다... 분위기가 좋다..?고 해야하나... 천하의 모쏠자식이라 판단은 잘 안되지만... 한 밤 중에 둘이서 따로 나와 이야기를 나누고.. 드디어 나에게도 러브코미디 같은 그런 전개가 일어나는 것인가..?)"
    #play sound "crow.ogg"
    narrator "(배경음으로 까마귀 소리가 들린다.)"
    narrator "(툭)"
    narrator "갑작스럽게 어깨에 무언가 내려앉는다. 뭔가 축축한 느낌. 아까도 느꼈던 그 특유의 냄새가 난다. 고개를 돌려 확인하고 싶지만, 그럴 수 없다. 이 순간에 너무나 몽글몽글하고, 두근두근거리는 마음에 쉽게 처다 볼 수가 없다."
    ch_player "(아아..이제 죽어도 좋아..정말 여한이 없어 오라 달콤한 죽음이여...)"
    ch_player "(그런데 잠시만... 분명 수영이는 반대쪽에 앉아있는데..? 그러면 이쪽 어깨에는 뭐가 있는거지???)"
    narrator "조심스럽게 고개를 돌려 확인하니 그곳에는 아까 수영이가 들고있던 생선이 올려져있다."
    ch_player "???? 이게 왜 여기.."
    ch_soodal "키이에엥에에에에에에에에에에에엑!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    narrator "짐승의 소리. 그렇다 이것은 영락없는 짐승의 소리이다. 마치 먹이를 빼앗겨 생존에 위협을 받기에 내지르는 위협의 아우성. 그야말로 야생의 울림이 들려온다."
    ch_player "ㅅ..수영아...??????"
    ch_soodal "...저저 까마귀가 내 생선을!!!@ 키에에에에에에에에에에에엑!!@!!!!!!@@@@!@!!@!@!@"
    narrator "세상에 맙소사, 오늘 학생회 일 하느라 한 끼도 제대로 못 챙겨먹었다더니... 아까 까마귀 소리가 복선이구나...."
    ch_player "수...수영아 여기 이거.. 받아.."
    ch_soodal "키!!@@@@ㄴ앤애앵ㄱ!!!!ㅇ..으어? 왜 이게 여기에..?"
    narrator "수영에게 생선을 건내주고 함께 돌아간다. 달은 여전히 포근하게 빛을 낸다. 나의 어깨에는 생선 비린내가 나고, 나의 귀에는 피가 흐르지만, 그래.. 이정도면 좋은 날이다."

    return





label episode_turtle_lunchdate:

    show bg_it_1
    #show scg_turtle_animal with dissolve
    show scg_yun_normal with dissolve
    show scg_heesul_normal
    show scg_suyeong_normal 
     
    narrator "동아리 방."
    narrator "각자 자신의 일에 몰입하고 있는 부원들이 있다."
    narrator "평소와 같은 풍경 -"
    narrator "[player_name]도 거기 껴서 할 일을 하고 있었다."
    narrator "오늘까지 제출인 과제가 있긴 하지만, 우리의 [player_name]은 비범해 그런 것 따위는 하지 않았다."
    narrator "과제 따위를 할 시간에, 인터넷 커뮤니티에서 애니메이션 “나는 내일의 아침밥이지만 당신은 오늘의 저녁밥입니다만? ~끼니를 챙겨먹는 것은 아주 중요해~”의 [player_name]의 정실은 G인지, K인지에 대해 커뮤니티에서 고급진 토론을 하고 있었다."
    narrator "아주 한심하게 보일 정도로, 중요한 일이니까."

    narrator "매우 중요한 문제를 풀어나가던 [player_name]에게, 귀연이 말을 걸었다."

    ch_turtle "서, 선배. 나 하고 싶은 말이 있는데........!"
    ch_player "어, 으응. 뭐?"
    ch_player "(헉, 무슨 일이지?)"
    ch_turtle "나...... 나!"
    ch_turtle "선배안녕나선배랑밥이먹고싶은데혹시괜찮을까? 오늘저녁도괜찮고목요일저녁도괜찮고나금요일에교수님이휴학을한다고해서 아니휴학이아니고자퇴인가? 아니자퇴는아닌데 으아앙이런말하고싶던게아니였는데~!!!!!! 아무튼교수님이금요일에수업이없다고그래서수업이없거든 그래서공강이라금요일도괜찮아!! 언제든지괜찮아!! 점심시간도다괜찮아!!"
    ch_player "(방금 뭐였지?)"
    ch_player "지금 나한테 바...... 밥사달라는 소리야?"
    ch_player "(뭔 거북이가 말을 이렇게 빠르게 해?)"
    ch_turtle "(천천히 얼굴을 끄떡인다.)"
    ch_player "그, 그래! 까짓거 밥 한 번 먹자. 내일 점심 어때?"
    ch_player "매뉴는......."
    ch_player "(큰일났다! 나 찐따라서 아는 밥집이 없는데....... 아! 그래 공대에 명물 하나 있지!)"
    ch_player "학식! 그래. 베이직하게 학식 먹자. 공식당 아직 안 먹어봤지?"
    ch_player "(여자 후배랑 밥약인데 고작 학식이라니! 쪼잔하다고 생각하지는 않겠지?)"
    ch_turtle "네에, 선배애......"
    ch_turtle "내애일 점시임시가안에 고옹시익다앙으로오 갈께요오......"
    ch_player "그래! 그럼 내일 보자."
    ch_player "(...... 말 멀쩡하게 하다가 갑자기 왜 저래?)"

    narrator "(다음 날. [player_name]은 오전시간 마지막 수업을 듣고 있었다......)"

    ch_player "(이 수업만 들으면 귀연과 밥을 먹으러 갈 수 있어!)"
    narrator "그렇지만 수업이 끝나질 않았다......!!!!!!"
    ch_player "(미친 교수!!!! 수업을 왜 안 끝내?)"
    ch_player "(그냥 지금 나가버릴까?)"
    ch_player "(근데 나가다가 교수한테 걸리기라도 하면?)"
    
    #흔들리는 효과
    ch_player "(그건 너무 쪽팔려...!!!!!!!)"
    
    
    narrator "([player_name], 할 수 없이 계속 자리에 앉아있는다."
    narrator "교수, 정해진 수업 시간에서 30분을 훌쩍 넘긴 뒤에야 끝내놓고도"
    narrator "미안하다는 말도 없이 쑥 나간다......)"
    ch_player "(늦었다아아아아아아-!!!!!!!)"
    narrator "([player_name], 벌떡 급하게 강의실을 뛰쳐나간다!)"

    narrator "(공식당 앞."
    narrator "입구에 줄서있는 수많은 사람들 사이에"
    narrator "귀연이 보인다.)"

    ch_turtle "어? 선배애,,,~"
    narrator "(귀연, 급하게 뛰어오는 [player_name]을 향해 앞발을 흔든다.)"
    ch_player "(헉헉거리며) 느, 늦어서 미안!"
    ch_turtle "아니에요! 저도 막 도착했어요."
    ch_player "매뉴 정했어? 뭐 먹고 싶은 거 있어?"
    ch_turtle "이거 어때요옹?"
    narrator "(귀연이 에브리타임 학식 탭을 키고는 “산더미 오리주물럭” 을 보여준다.)"
    ch_player "이거...... 둘이 먹는 거 아니야?"
    ch_turtle "네엥. 무슨 문제라도 있어요?"
    ch_turtle "선배 혹시 오리 알레르기라도 있어요?"
    ch_player "(그러네......! 나 혼자가 아니니까 이제 이거 먹을 수 있네)"
    ch_player "(연이가 있으니까! 혼자가 아니야! 그러니까......)"
    ch_player "(2인 매뉴를 시킬 수 있어!)"
    ch_player "아니, 좋아! 이거 먹자!"
    narrator "([player_name], 귀연과 함께 키오스크 앞에 줄을 선다."
    narrator "식권을 받고는, 같이 음식을 받으러 식당 안으로 들어간다.)"
    ch_player "(맨날 먹는 학식인데, 설랜다!)"
    ch_player "(학교 입학하고 처음 먹을때도 이렇지는 않았는데!)"
    ch_player "(내가 누구랑, 그것도 여자랑...... 이렇게 귀여운 후배랑 밥을 먹다니! 행복해! 이거 다 꿈이여도 괜차......)"
    ch_turtle "선배애~"
    ch_player "헉! 무, 뭐 할 말 있어?"
    ch_turtle "우리 오리주물럭 먹을려어면 이거 챙겨야 하는 거 아니에요?"
    narrator "(귀연, 한 구석에 가득 쌓여있는 가스버너를 가르킨다.)"
    ch_player "(안 먹어봐서 몰랐다!)"
    ch_player "그러네! 깜빡할 뻔 했다. 내가 가지고 올께."
    ch_turtle "아니에요옹. 제가 챙겨서 자리 잡고 있을께요. 선배는 오리주물럭 받아주세요!"
    ch_player "그, 그러네! 그게 좋겠다. 얼른 가지고 올께!"
    narrator "([player_name], 머쓱하게 ‘산더미 오리주물럭’ 줄에 선다."
    narrator "귀연은 특유의 느릿느릿한 걸음으로 자리를 잡으러 간다.)"
    ch_player "(으아아, 지금 뭔 정신인지 하나도 모르겠다!)"

    narrator "..."
    ch_turtle "선배애, 진짜 선배가 다 사는 거에요? 얻어먹어도 되는 거에요?"
    ch_player "어, 당연하지! 밥약 국룰이 선배가 사는거잖아."
    ch_turtle "진짜 괜찮아요?"
    ch_player "고작 학식인데 뭘...... 솔직히 더 좋은 거 못 사줘서 미안해."
    ch_turtle "와아, 선배 멋져~"

    narrator "([player_name]이 정신을 차렸을 때, 식사는 끝난 지 오래였고"
    narrator "[player_name]과 귀연은 공식당 밖으로 나와 있었다!)"
    ch_player "(으아아, 벌써 다 먹었다고? 오리가 코로 들어갔는지 귀로 들어갔는지 모르겠다....... 그릇 반납은 제대로 했겠지?)"
    narrator "(귀연을 바라보며)"
    ch_player "잘 먹었어?"
    ch_turtle "(특유의 온화한 웃음을 지으며 대답한다.) 네엥!"
    ch_player "(진짜 잘 먹은 거 맞겠지......)"
    ch_turtle "오늘 맛있었어요!"
    ch_player "(고작 학식인데, 이렇게 웃어주다니!)"
    ch_player "다행이네. 밥 먹었으니까 디져트 먹으러 갈까?"
    ch_turtle "헉, 좋아요!"
    narrator "(갑자기 귀연의 핸드폰에서 알림이 울린다."
    narrator "핸드폰을 꺼내 알림을 확인하더니, 갑자기 귀연의 눈이 확 커진다.)"

    #놀라는는
    ch_turtle "허어억맞다아이거를왜까먹고있었지?!?!?"
    ch_turtle "(시무룩한 표정으로 [player_name]을 바라보며) 저 일이 있어서 가봐야 할 것 같아요."
    ch_turtle "커피까지 먹고 싶었는데ㅜㅜ......"
    ch_player "아니야! 그러면 가 봐야지. 커피야 뭐 나중에도 먹을 수 있으니까."
    ch_turtle "(갑자기 초롱초롱한 눈빛으로) 진짜 나중에 저랑 커피 먹을꺼에요~!?!?"
    ch_player "(으아, 너무 귀여운데 부담스럽다!)"
    ch_player "어. 먹자! 못 먹을 이유 없잖아!"
    ch_turtle "약속한거죠? 진짜진짜 나중에 저랑 커피 먹어줘야 해요!"
    ch_turtle "저 그럼 이제 가볼께요. 선배, 나중에 동방에서 봐요~"
    ch_player "엉. 잘 들어가 봐~"
    narrator "(귀연, 아쉬운 듯이 미적미적 걸어간다.)"
    ch_player "(와아, 나 지금 여자후배랑 밥약 한 건가?)"
    ch_player "(진짜 꿈 같다...... 사실 나 코마상태 아닐까?)"
    ch_player "(밥 제대로 먹은 거 맞겠지?)"
    ch_player "(뭐 말이나...... 그런 거 실수 한 거는 없겠지......)"
    ch_player "(근데 진짜 기분 좋다!)"
    ch_player "(이제나마 드디어 캠퍼스 생활 해 보는구나!)"
    narrator "([player_name], 어딘가 경쾌한 걸음으로 오후 수업을 들으러 IT 1호관으로 간다.)"
    ch_player "(근데 진짜, 맛있게 먹은 거 맞겠지?)"

    return

label episode_heron_midterm:
    scene bg_chungdam with fade # 장면 페이드 인
    
    narrator "즐거운 신학기가 흘러가고 찾아온 중간고사 기간."
    narrator "우리의 [player_name]도 시험 준비를 피할 수 없었다......."

    show scg_banwoo with dissolve # 캐릭터 CG 페이드 인
    ch_player "(으으, 공부 싫어. 시험 치기 싫어.......)"
    ch_player "오늘의 수업이 모두 끝난 오후."
    ch_player "그러나 당신은 집에 가지 못한다."
    ch_player "당신은 어두운 표정으로 무거운 전공책들을 잔뜩 짊어진 체 도서관으로 가고 있다."
    ch_player "뒤에서 인기척이 느껴지지만 당신은 그것을 신경 쓸 겨를이 없다."
    ch_player "무시하고 계속 도서관으로 향하는데......."

    show scg_banwoo at bounce
    ch_player "헤에엑!"

    narrator "뾰족한 무언가가 당신의 목을 툭 쳤다."
    narrator "당신은 깜짝 놀라 제자리에서 넘어진다."
    hide scg_banwoo with dissolve

    ch_unknown "야, 나야!"
    ch_player "서연 선배?"

    show scg_heron_animal with dissolve
    ch_heron "왜 이렇게 놀라."    

    ch_player "아니, 사람을 부리로 치면 어떻게 해요!"
    ch_player "그리고 어깨도 아니고 갑자기 목을.......!"

    narrator "당신은 하고 싶은 말이 많지만 놀라 말이 제대로 나오지 않는다."

    ch_heron "얼굴 새뻘건 거 봐. 통통한 지렁이같다."
    ch_player "선배, 사람한테 지렁이가 뭐에요?"
    ch_heron "맛있는데 뭐? 지금 공부하러 가는 중이지?"
    ch_player "네, 네......."
    ch_heron "같이 가자."
    ch_player "지, 진짜, 진짜요?"
    ch_heron "아니. 얼굴이 더 빨개졌네. 그냥 도서관 같이 가자는 건데 왜 그래. 싫어?"
    
    ch_player "아, 아뇨. 아뇨! 너, 너, 너, 너무 좋아요! 진짜로요!"
    ch_player "(헉, 내가 여자랑, 여자랑 단 둘이 도서관을?"
    ch_player "내 인생에 여자가 있다니.......! 그것도 저렇게 글레머하고 이쁜 선배라니!"
    ch_player "이 모든 게 그냥 다 꿈 같다.......)"

    ch_heron "야, 적당히 해. 쪽팔려."
    ch_player "죄, 죄송! 죄송해요!"
    ch_heron "짜증나. 그냥 닥쳐."
    ch_player "(아는 여자가 생겨도 나는 계속 찐따구나!)"

    hide scg_heron_animal with dissolve

    scene bg_library_inside with fade
    narrator "도서관 이미지는 그냥 인터넷에서 가져온 예시입니다."
    narrator "당신과 희설은 함께 도서관 신관으로 들어간다."
    narrator "잡은 자리는 오픈석 두 자리. 서로 마주보는 자리다."
    narrator "함께 열람실에 입실한 뒤, 당신은 서연과 마주보고 앉아 공부를 시작한다."
    narrator "희설이 신경쓰이던 것도 잠시,"
    narrator "전공 도서의 방대한 내용에 희설이고 뭐고 신경 쓸 겨를이 없게 된다......"

    ch_player "(공부"
    ch_player "공부"
    ch_player "공부... 책, 책,"
    ch_player "전공, 전공,,"
    ch_player "아, 하나도 이해가 안 돼...... 벌써 그른 것 같다."
    ch_player "장학금하고 작별인사를 나눠야 할 때가 온 것 같다."
    ch_player "이대로라면 진짜 학사경고 받을지도 모르겠다!)"

    narrator "머리를 쥐어뜯고 있던 [player_name]에게 갈서연이 쪽지를 툭 던진다."
    
    
    show scg_heron_animal with dissolve
    ch_heron_letter "\[ 모르는거 있어?\ ]"
    ch_player "(모르는거야 많지. 근데 선배는 본전공도 아니고 복수전공이신데......"
    ch_player "이걸 물어봐도 되는 걸까?"
    ch_player "하이씨. 그냥 말이라도 한 번 꺼내보자.)"
    ch_player "(소곤거리며) 여기 이 문제....... 지난번에 교수님이 풀어주셨는데도 이해가 안 돼요."

    narrator "희설은 당신의 책을 쑥 뺏어가더니 쓱 흝는다."
    narrator "연습장에 수식을 끄적이더니, 당신의 책에 무언가를 적고 돌려준다."

    ch_heron "이걸...... 왜....... 몰라?"
    ch_player "(살짝 언성을 높인다.) 어려우니까 그러죠! 선배, 그럼 선배는 이거 풀 수 있어요?"
    ch_heron "(조용히 하라는 듯 입술에 손가락을 올린다.)"
    ch_player "(아차, 지금 도서관이었지!)"

    narrator "희설은 조용히 자리에서 일어나며 밖으로 나가자고 손짓한다."
    narrator "동시에 입모양으로 뭐라고 말하는 듯 하지만, 눈치가 없는 당신은 알아먹지 못한다."
    narrator "당신과 서연은 열람실에서 나온다."
    hide scg_heron_animal with dissolve

    scene bg_library_outside with fade
    show scg_heron_animal with dissolve
    ch_heron "너가 보여줬던 문제. 이렇게 이렇게 해서. 이렇게 하면 바로 답 나오는 거잖아."
    ch_heron "아주 기초적인 문제인데, 이것도 못 풀면 어떻게 해?"
    ch_player "어....... 아!"

    narrator "당신은 속으로 유레카를 외친다."

    ch_heron "아까 책 들고 나오라고 했는데 왜 빈손이야? 풀어주려고 했는데."
    ch_player "그...... 런거였어요?"

    narrator "희설은 무언의 눈빛으로 당신을 바라본다. 따가운 눈빛이다."

    ch_heron "됐고, 나온 김에 카페인 수혈하러 가자."
    ch_player "뭘 수...... 혈이요?"
    ch_heron "(한숨을 쉰다.) 카페가자고."
    ch_player "네...... 네!"
